export interface Events_waits_summary_by_instance {
    EVENT_NAME: string;

    OBJECT_INSTANCE_BEGIN: number;

    COUNT_STAR: number;

    SUM_TIMER_WAIT: number;

    MIN_TIMER_WAIT: number;

    AVG_TIMER_WAIT: number;

    MAX_TIMER_WAIT: number;

}