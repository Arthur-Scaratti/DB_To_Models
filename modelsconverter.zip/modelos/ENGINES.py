
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class ENGINES(Base):
    __tablename__ = 'ENGINES'

    ENGINE = Column(String, nullable=False)

    SUPPORT = Column(String, nullable=False)

    COMMENT = Column(String, nullable=False)

    TRANSACTIONS = Column(String)

    XA = Column(String)

    SAVEPOINTS = Column(String)

