
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const COLLATION_CHARACTER_SET_APPLICABILITY = Sequelize.define('COLLATION_CHARACTER_SET_APPLICABILITY', {

    COLLATION_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CHARACTER_SET_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    FULL_COLLATION_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    IS_DEFAULT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = COLLATION_CHARACTER_SET_APPLICABILITY;