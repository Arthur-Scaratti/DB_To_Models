
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Host_cache extends Model
{
    protected $table = 'host_cache';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'IP',
        'HOST',
        'HOST_VALIDATED',
        'SUM_CONNECT_ERRORS',
        'COUNT_HOST_BLOCKED_ERRORS',
        'COUNT_NAMEINFO_TRANSIENT_ERRORS',
        'COUNT_NAMEINFO_PERMANENT_ERRORS',
        'COUNT_FORMAT_ERRORS',
        'COUNT_ADDRINFO_TRANSIENT_ERRORS',
        'COUNT_ADDRINFO_PERMANENT_ERRORS',
        'COUNT_FCRDNS_ERRORS',
        'COUNT_HOST_ACL_ERRORS',
        'COUNT_NO_AUTH_PLUGIN_ERRORS',
        'COUNT_AUTH_PLUGIN_ERRORS',
        'COUNT_HANDSHAKE_ERRORS',
        'COUNT_PROXY_USER_ERRORS',
        'COUNT_PROXY_USER_ACL_ERRORS',
        'COUNT_AUTHENTICATION_ERRORS',
        'COUNT_SSL_ERRORS',
        'COUNT_MAX_USER_CONNECTIONS_ERRORS',
        'COUNT_MAX_USER_CONNECTIONS_PER_HOUR_ERRORS',
        'COUNT_DEFAULT_DATABASE_ERRORS',
        'COUNT_INIT_CONNECT_ERRORS',
        'COUNT_LOCAL_ERRORS',
        'COUNT_UNKNOWN_ERRORS',
        'FIRST_SEEN',
        'LAST_SEEN',
        'FIRST_ERROR_SEEN',
        'LAST_ERROR_SEEN',

    ];
}
