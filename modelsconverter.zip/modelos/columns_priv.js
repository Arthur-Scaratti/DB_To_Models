
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Columns_priv = Sequelize.define('columns_priv', {

    Host: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Db: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    User: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Table_name: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Column_name: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Timestamp: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    Column_priv: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Columns_priv;