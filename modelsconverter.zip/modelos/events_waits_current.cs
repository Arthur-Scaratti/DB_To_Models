
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_waits_current
    {

        [Required]
        public long THREAD_ID { get; set; }
        /// THREAD_ID
        [Required]
        public long EVENT_ID { get; set; }
        /// EVENT_ID
    
        public long END_EVENT_ID { get; set; }
        /// END_EVENT_ID
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [StringLength(64)]
        public string? SOURCE { get; set; }
        /// SOURCE
    
        public long TIMER_START { get; set; }
        /// TIMER_START
    
        public long TIMER_END { get; set; }
        /// TIMER_END
    
        public long TIMER_WAIT { get; set; }
        /// TIMER_WAIT
    
        public int SPINS { get; set; }
        /// SPINS
        [StringLength(64)]
        public string? OBJECT_SCHEMA { get; set; }
        /// OBJECT_SCHEMA
        [StringLength(512)]
        public string? OBJECT_NAME { get; set; }
        /// OBJECT_NAME
        [StringLength(64)]
        public string? INDEX_NAME { get; set; }
        /// INDEX_NAME
        [StringLength(64)]
        public string? OBJECT_TYPE { get; set; }
        /// OBJECT_TYPE
        [Required]
        public long OBJECT_INSTANCE_BEGIN { get; set; }
        /// OBJECT_INSTANCE_BEGIN
    
        public long NESTING_EVENT_ID { get; set; }
        /// NESTING_EVENT_ID
    
        public string? NESTING_EVENT_TYPE { get; set; }
        /// NESTING_EVENT_TYPE
        [Required]
        [StringLength(32)]
        public string? OPERATION { get; set; }
        /// OPERATION
    
        public long NUMBER_OF_BYTES { get; set; }
        /// NUMBER_OF_BYTES
    
        public int FLAGS { get; set; }
        /// FLAGS
    }
}
