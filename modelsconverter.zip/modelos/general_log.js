
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const General_log = Sequelize.define('general_log', {

    Event_time: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    User_host: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

    Thread_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Server_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    Command_type: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    Argument: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = General_log;