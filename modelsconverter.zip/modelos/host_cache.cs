
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_cache
    {

        [Required]
        [StringLength(64)]
        public string? IP { get; set; }
        /// IP
        [StringLength(255)]
        public string? HOST { get; set; }
        /// HOST
        [Required]
        public string? HOST_VALIDATED { get; set; }
        /// HOST_VALIDATED
        [Required]
        public long SUM_CONNECT_ERRORS { get; set; }
        /// SUM_CONNECT_ERRORS
        [Required]
        public long COUNT_HOST_BLOCKED_ERRORS { get; set; }
        /// COUNT_HOST_BLOCKED_ERRORS
        [Required]
        public long COUNT_NAMEINFO_TRANSIENT_ERRORS { get; set; }
        /// COUNT_NAMEINFO_TRANSIENT_ERRORS
        [Required]
        public long COUNT_NAMEINFO_PERMANENT_ERRORS { get; set; }
        /// COUNT_NAMEINFO_PERMANENT_ERRORS
        [Required]
        public long COUNT_FORMAT_ERRORS { get; set; }
        /// COUNT_FORMAT_ERRORS
        [Required]
        public long COUNT_ADDRINFO_TRANSIENT_ERRORS { get; set; }
        /// COUNT_ADDRINFO_TRANSIENT_ERRORS
        [Required]
        public long COUNT_ADDRINFO_PERMANENT_ERRORS { get; set; }
        /// COUNT_ADDRINFO_PERMANENT_ERRORS
        [Required]
        public long COUNT_FCRDNS_ERRORS { get; set; }
        /// COUNT_FCRDNS_ERRORS
        [Required]
        public long COUNT_HOST_ACL_ERRORS { get; set; }
        /// COUNT_HOST_ACL_ERRORS
        [Required]
        public long COUNT_NO_AUTH_PLUGIN_ERRORS { get; set; }
        /// COUNT_NO_AUTH_PLUGIN_ERRORS
        [Required]
        public long COUNT_AUTH_PLUGIN_ERRORS { get; set; }
        /// COUNT_AUTH_PLUGIN_ERRORS
        [Required]
        public long COUNT_HANDSHAKE_ERRORS { get; set; }
        /// COUNT_HANDSHAKE_ERRORS
        [Required]
        public long COUNT_PROXY_USER_ERRORS { get; set; }
        /// COUNT_PROXY_USER_ERRORS
        [Required]
        public long COUNT_PROXY_USER_ACL_ERRORS { get; set; }
        /// COUNT_PROXY_USER_ACL_ERRORS
        [Required]
        public long COUNT_AUTHENTICATION_ERRORS { get; set; }
        /// COUNT_AUTHENTICATION_ERRORS
        [Required]
        public long COUNT_SSL_ERRORS { get; set; }
        /// COUNT_SSL_ERRORS
        [Required]
        public long COUNT_MAX_USER_CONNECTIONS_ERRORS { get; set; }
        /// COUNT_MAX_USER_CONNECTIONS_ERRORS
        [Required]
        public long COUNT_MAX_USER_CONNECTIONS_PER_HOUR_ERRORS { get; set; }
        /// COUNT_MAX_USER_CONNECTIONS_PER_HOUR_ERRORS
        [Required]
        public long COUNT_DEFAULT_DATABASE_ERRORS { get; set; }
        /// COUNT_DEFAULT_DATABASE_ERRORS
        [Required]
        public long COUNT_INIT_CONNECT_ERRORS { get; set; }
        /// COUNT_INIT_CONNECT_ERRORS
        [Required]
        public long COUNT_LOCAL_ERRORS { get; set; }
        /// COUNT_LOCAL_ERRORS
        [Required]
        public long COUNT_UNKNOWN_ERRORS { get; set; }
        /// COUNT_UNKNOWN_ERRORS
        [Required]
        public string? FIRST_SEEN { get; set; }
        /// FIRST_SEEN
        [Required]
        public string? LAST_SEEN { get; set; }
        /// LAST_SEEN
    
        public string? FIRST_ERROR_SEEN { get; set; }
        /// FIRST_ERROR_SEEN
    
        public string? LAST_ERROR_SEEN { get; set; }
        /// LAST_ERROR_SEEN
    }
}
