
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Func extends Model
{
    protected $table = 'func';
   
    protected $primaryKey = ['Name'];

    public $timestamps = false;

    protected $fillable = [
        'Name',
        'Ret',
        'Dl',
        'Type',

    ];
}
