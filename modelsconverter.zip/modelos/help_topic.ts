export interface Help_topic {
    Help_topic_id: number;

    Name: string;

    Help_category_id: number;

    Description: string;

    Example: string;

    Url: string;

}