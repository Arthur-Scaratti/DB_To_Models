
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class COLLATION_CHARACTER_SET_APPLICABILITY(Base):
    __tablename__ = 'COLLATION_CHARACTER_SET_APPLICABILITY'

    COLLATION_NAME = Column(String, nullable=False)

    CHARACTER_SET_NAME = Column(String, nullable=False)

    FULL_COLLATION_NAME = Column(String, nullable=False)

    ID = Column(BigInteger, nullable=False)

    IS_DEFAULT = Column(String, nullable=False)

