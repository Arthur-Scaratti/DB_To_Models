
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const INDEX_STATISTICS = Sequelize.define('INDEX_STATISTICS', {

    TABLE_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    INDEX_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    ROWS_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = INDEX_STATISTICS;