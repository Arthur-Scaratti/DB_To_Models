import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class events_statements_summary_by_user_by_event_name {
    private String USER;

     private String EVENT_NAME;

     private long COUNT_STAR;

     private long SUM_TIMER_WAIT;

     private long MIN_TIMER_WAIT;

     private long AVG_TIMER_WAIT;

     private long MAX_TIMER_WAIT;

     private long SUM_LOCK_TIME;

     private long SUM_ERRORS;

     private long SUM_WARNINGS;

     private long SUM_ROWS_AFFECTED;

     private long SUM_ROWS_SENT;

     private long SUM_ROWS_EXAMINED;

     private long SUM_CREATED_TMP_DISK_TABLES;

     private long SUM_CREATED_TMP_TABLES;

     private long SUM_SELECT_FULL_JOIN;

     private long SUM_SELECT_FULL_RANGE_JOIN;

     private long SUM_SELECT_RANGE;

     private long SUM_SELECT_RANGE_CHECK;

     private long SUM_SELECT_SCAN;

     private long SUM_SORT_MERGE_PASSES;

     private long SUM_SORT_RANGE;

     private long SUM_SORT_ROWS;

     private long SUM_SORT_SCAN;

     private long SUM_NO_INDEX_USED;

     private long SUM_NO_GOOD_INDEX_USED;

 }