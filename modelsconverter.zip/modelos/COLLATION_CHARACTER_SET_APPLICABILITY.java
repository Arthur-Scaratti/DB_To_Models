import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class COLLATION_CHARACTER_SET_APPLICABILITY {
    private String COLLATION_NAME;

     private String CHARACTER_SET_NAME;

     private String FULL_COLLATION_NAME;

     private long ID;

     private String IS_DEFAULT;

 }