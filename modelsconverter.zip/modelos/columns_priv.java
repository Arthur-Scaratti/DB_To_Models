import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class columns_priv {
    @Id
    private String Host;

     @Id
    private String Db;

     @Id
    private String User;

     @Id
    private String Table_name;

     @Id
    private String Column_name;

     private String Timestamp;

     private String Column_priv;

 }