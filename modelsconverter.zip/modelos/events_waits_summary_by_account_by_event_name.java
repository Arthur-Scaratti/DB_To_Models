import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class events_waits_summary_by_account_by_event_name {
    private String USER;

     private String HOST;

     private String EVENT_NAME;

     private long COUNT_STAR;

     private long SUM_TIMER_WAIT;

     private long MIN_TIMER_WAIT;

     private long AVG_TIMER_WAIT;

     private long MAX_TIMER_WAIT;

 }