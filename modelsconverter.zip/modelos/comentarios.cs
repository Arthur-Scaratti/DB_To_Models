
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Comentarios
    {

        [Required]
        [Key]
        public int COMMENT_ID { get; set; }
        /// COMMENT_ID
    
        public int CAP_ID { get; set; }
        /// CAP_ID
        [Required]
        public int NOVEL_ID { get; set; }
        /// NOVEL_ID
    
        public int CAP_NRO { get; set; }
        /// CAP_NRO
        [Required]
        [StringLength(1000)]
        public string? CONTENT { get; set; }
        /// CONTENT
    
        public int SENDER { get; set; }
        /// SENDER
    
        public int RECIEVER { get; set; }
        /// RECIEVER
        [StringLength(2)]
        public string? LANGUAGE { get; set; }
        /// LANGUAGE
    }
}
