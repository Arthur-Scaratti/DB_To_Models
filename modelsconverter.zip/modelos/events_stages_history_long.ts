export interface Events_stages_history_long {
    THREAD_ID: number;

    EVENT_ID: number;

    END_EVENT_ID: number;

    EVENT_NAME: string;

    SOURCE: string;

    TIMER_START: number;

    TIMER_END: number;

    TIMER_WAIT: number;

    WORK_COMPLETED: number;

    WORK_ESTIMATED: number;

    NESTING_EVENT_ID: number;

    NESTING_EVENT_TYPE: string;

}