import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class help_keyword {
    @Id
    private int Help_keyword_id;

     private String Name;

 }