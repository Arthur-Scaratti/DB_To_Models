export interface Event {
    Db: string;

    Name: string;

    Body: any;

    Definer: string;

    Execute_at: Date;

    Interval_value: number;

    Interval_field: string;

    Created: string;

    Modified: string;

    Last_executed: Date;

    Starts: Date;

    Ends: Date;

    Status: string;

    On_completion: string;

    Sql_mode: string;

    Comment: string;

    Originator: number;

    Time_zone: string;

    Character_set_client: string;

    Collation_connection: string;

    Db_collation: string;

    Body_utf8: any;

}