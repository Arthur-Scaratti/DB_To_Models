import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class GLOBAL_VARIABLES {
    private String VARIABLE_NAME;

     private String VARIABLE_VALUE;

 }