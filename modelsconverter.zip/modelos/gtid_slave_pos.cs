
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Gtid_slave_pos
    {

        [Required]
        [Key]
        public int Domain_id { get; set; }
        /// domain_id
        [Required]
        [Key]
        public long Sub_id { get; set; }
        /// sub_id
        [Required]
        public int Server_id { get; set; }
        /// server_id
        [Required]
        public long Seq_no { get; set; }
        /// seq_no
    }
}
