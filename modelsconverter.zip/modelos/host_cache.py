
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Host_cache(Base):
    __tablename__ = 'host_cache'

    IP = Column(String, nullable=False)

    HOST = Column(String)

    HOST_VALIDATED = Column(Enum, nullable=False)

    SUM_CONNECT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_HOST_BLOCKED_ERRORS = Column(BigInteger, nullable=False)

    COUNT_NAMEINFO_TRANSIENT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_NAMEINFO_PERMANENT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_FORMAT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_ADDRINFO_TRANSIENT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_ADDRINFO_PERMANENT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_FCRDNS_ERRORS = Column(BigInteger, nullable=False)

    COUNT_HOST_ACL_ERRORS = Column(BigInteger, nullable=False)

    COUNT_NO_AUTH_PLUGIN_ERRORS = Column(BigInteger, nullable=False)

    COUNT_AUTH_PLUGIN_ERRORS = Column(BigInteger, nullable=False)

    COUNT_HANDSHAKE_ERRORS = Column(BigInteger, nullable=False)

    COUNT_PROXY_USER_ERRORS = Column(BigInteger, nullable=False)

    COUNT_PROXY_USER_ACL_ERRORS = Column(BigInteger, nullable=False)

    COUNT_AUTHENTICATION_ERRORS = Column(BigInteger, nullable=False)

    COUNT_SSL_ERRORS = Column(BigInteger, nullable=False)

    COUNT_MAX_USER_CONNECTIONS_ERRORS = Column(BigInteger, nullable=False)

    COUNT_MAX_USER_CONNECTIONS_PER_HOUR_ERRORS = Column(BigInteger, nullable=False)

    COUNT_DEFAULT_DATABASE_ERRORS = Column(BigInteger, nullable=False)

    COUNT_INIT_CONNECT_ERRORS = Column(BigInteger, nullable=False)

    COUNT_LOCAL_ERRORS = Column(BigInteger, nullable=False)

    COUNT_UNKNOWN_ERRORS = Column(BigInteger, nullable=False)

    FIRST_SEEN = Column(DateTime, nullable=False)

    LAST_SEEN = Column(DateTime, nullable=False)

    FIRST_ERROR_SEEN = Column(DateTime)

    LAST_ERROR_SEEN = Column(DateTime)

