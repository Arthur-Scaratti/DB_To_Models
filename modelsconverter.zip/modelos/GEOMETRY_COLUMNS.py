
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class GEOMETRY_COLUMNS(Base):
    __tablename__ = 'GEOMETRY_COLUMNS'

    F_TABLE_CATALOG = Column(String, nullable=False)

    F_TABLE_SCHEMA = Column(String, nullable=False)

    F_TABLE_NAME = Column(String, nullable=False)

    F_GEOMETRY_COLUMN = Column(String, nullable=False)

    G_TABLE_CATALOG = Column(String, nullable=False)

    G_TABLE_SCHEMA = Column(String, nullable=False)

    G_TABLE_NAME = Column(String, nullable=False)

    G_GEOMETRY_COLUMN = Column(String, nullable=False)

    STORAGE_TYPE = Column(Integer, nullable=False)

    GEOMETRY_TYPE = Column(Integer, nullable=False)

    COORD_DIMENSION = Column(Integer, nullable=False)

    MAX_PPR = Column(Integer, nullable=False)

    SRID = Column(SmallInteger, nullable=False)

