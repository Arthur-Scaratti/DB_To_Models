export interface Events_statements_summary_by_digest {
    SCHEMA_NAME: string;

    DIGEST: string;

    DIGEST_TEXT: string;

    COUNT_STAR: number;

    SUM_TIMER_WAIT: number;

    MIN_TIMER_WAIT: number;

    AVG_TIMER_WAIT: number;

    MAX_TIMER_WAIT: number;

    SUM_LOCK_TIME: number;

    SUM_ERRORS: number;

    SUM_WARNINGS: number;

    SUM_ROWS_AFFECTED: number;

    SUM_ROWS_SENT: number;

    SUM_ROWS_EXAMINED: number;

    SUM_CREATED_TMP_DISK_TABLES: number;

    SUM_CREATED_TMP_TABLES: number;

    SUM_SELECT_FULL_JOIN: number;

    SUM_SELECT_FULL_RANGE_JOIN: number;

    SUM_SELECT_RANGE: number;

    SUM_SELECT_RANGE_CHECK: number;

    SUM_SELECT_SCAN: number;

    SUM_SORT_MERGE_PASSES: number;

    SUM_SORT_RANGE: number;

    SUM_SORT_ROWS: number;

    SUM_SORT_SCAN: number;

    SUM_NO_INDEX_USED: number;

    SUM_NO_GOOD_INDEX_USED: number;

    FIRST_SEEN: string;

    LAST_SEEN: string;

}