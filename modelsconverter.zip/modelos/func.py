
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Func(Base):
    __tablename__ = 'func'

    Name = Column(String, primary_key=True, nullable=False)

    Ret = Column(Integer, nullable=False)

    Dl = Column(String, nullable=False)

    Type = Column(Enum, nullable=False)

