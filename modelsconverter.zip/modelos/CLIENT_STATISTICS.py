
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class CLIENT_STATISTICS(Base):
    __tablename__ = 'CLIENT_STATISTICS'

    CLIENT = Column(String, nullable=False)

    TOTAL_CONNECTIONS = Column(BigInteger, nullable=False)

    CONCURRENT_CONNECTIONS = Column(BigInteger, nullable=False)

    CONNECTED_TIME = Column(BigInteger, nullable=False)

    BUSY_TIME = Column(Float, nullable=False)

    CPU_TIME = Column(Float, nullable=False)

    BYTES_RECEIVED = Column(BigInteger, nullable=False)

    BYTES_SENT = Column(BigInteger, nullable=False)

    BINLOG_BYTES_WRITTEN = Column(BigInteger, nullable=False)

    ROWS_READ = Column(BigInteger, nullable=False)

    ROWS_SENT = Column(BigInteger, nullable=False)

    ROWS_DELETED = Column(BigInteger, nullable=False)

    ROWS_INSERTED = Column(BigInteger, nullable=False)

    ROWS_UPDATED = Column(BigInteger, nullable=False)

    SELECT_COMMANDS = Column(BigInteger, nullable=False)

    UPDATE_COMMANDS = Column(BigInteger, nullable=False)

    OTHER_COMMANDS = Column(BigInteger, nullable=False)

    COMMIT_TRANSACTIONS = Column(BigInteger, nullable=False)

    ROLLBACK_TRANSACTIONS = Column(BigInteger, nullable=False)

    DENIED_CONNECTIONS = Column(BigInteger, nullable=False)

    LOST_CONNECTIONS = Column(BigInteger, nullable=False)

    ACCESS_DENIED = Column(BigInteger, nullable=False)

    EMPTY_QUERIES = Column(BigInteger, nullable=False)

    TOTAL_SSL_CONNECTIONS = Column(BigInteger, nullable=False)

    MAX_STATEMENT_TIME_EXCEEDED = Column(BigInteger, nullable=False)

