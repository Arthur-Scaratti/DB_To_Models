
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class COLUMNS
    {

        [Required]
        [StringLength(512)]
        public string? TABLE_CATALOG { get; set; }
        /// TABLE_CATALOG
        [Required]
        [StringLength(64)]
        public string? TABLE_SCHEMA { get; set; }
        /// TABLE_SCHEMA
        [Required]
        [StringLength(64)]
        public string? TABLE_NAME { get; set; }
        /// TABLE_NAME
        [Required]
        [StringLength(64)]
        public string? COLUMN_NAME { get; set; }
        /// COLUMN_NAME
        [Required]
        public long ORDINAL_POSITION { get; set; }
        /// ORDINAL_POSITION
    
        public string? COLUMN_DEFAULT { get; set; }
        /// COLUMN_DEFAULT
        [Required]
        [StringLength(3)]
        public string? IS_NULLABLE { get; set; }
        /// IS_NULLABLE
        [Required]
        [StringLength(64)]
        public string? DATA_TYPE { get; set; }
        /// DATA_TYPE
    
        public long CHARACTER_MAXIMUM_LENGTH { get; set; }
        /// CHARACTER_MAXIMUM_LENGTH
    
        public long CHARACTER_OCTET_LENGTH { get; set; }
        /// CHARACTER_OCTET_LENGTH
    
        public long NUMERIC_PRECISION { get; set; }
        /// NUMERIC_PRECISION
    
        public long NUMERIC_SCALE { get; set; }
        /// NUMERIC_SCALE
    
        public long DATETIME_PRECISION { get; set; }
        /// DATETIME_PRECISION
        [StringLength(32)]
        public string? CHARACTER_SET_NAME { get; set; }
        /// CHARACTER_SET_NAME
        [StringLength(64)]
        public string? COLLATION_NAME { get; set; }
        /// COLLATION_NAME
        [Required]
        public string? COLUMN_TYPE { get; set; }
        /// COLUMN_TYPE
        [Required]
        [StringLength(3)]
        public string? COLUMN_KEY { get; set; }
        /// COLUMN_KEY
        [Required]
        [StringLength(80)]
        public string? EXTRA { get; set; }
        /// EXTRA
        [Required]
        [StringLength(80)]
        public string? PRIVILEGES { get; set; }
        /// PRIVILEGES
        [Required]
        [StringLength(1024)]
        public string? COLUMN_COMMENT { get; set; }
        /// COLUMN_COMMENT
        [Required]
        [StringLength(6)]
        public string? IS_GENERATED { get; set; }
        /// IS_GENERATED
    
        public string? GENERATION_EXPRESSION { get; set; }
        /// GENERATION_EXPRESSION
    }
}
