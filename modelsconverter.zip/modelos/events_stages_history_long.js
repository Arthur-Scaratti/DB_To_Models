
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Events_stages_history_long = Sequelize.define('events_stages_history_long', {

    THREAD_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    END_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    SOURCE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    TIMER_START: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_END: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    WORK_COMPLETED: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    WORK_ESTIMATED: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NESTING_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NESTING_EVENT_TYPE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Events_stages_history_long;