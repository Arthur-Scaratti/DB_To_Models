export interface General_log {
    Event_time: string;

    User_host: string;

    Thread_id: number;

    Server_id: number;

    Command_type: string;

    Argument: string;

}