export interface CHECK_CONSTRAINTS {
    CONSTRAINT_CATALOG: string;

    CONSTRAINT_SCHEMA: string;

    TABLE_NAME: string;

    CONSTRAINT_NAME: string;

    LEVEL: string;

    CHECK_CLAUSE: string;

}