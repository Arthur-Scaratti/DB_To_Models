
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Events_waits_history = Sequelize.define('events_waits_history', {

    THREAD_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    END_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    SOURCE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    TIMER_START: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_END: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    SPINS: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    OBJECT_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    INDEX_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_TYPE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_INSTANCE_BEGIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    NESTING_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NESTING_EVENT_TYPE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    OPERATION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    NUMBER_OF_BYTES: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    FLAGS: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Events_waits_history;