
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class CHARACTER_SETS(Base):
    __tablename__ = 'CHARACTER_SETS'

    CHARACTER_SET_NAME = Column(String, nullable=False)

    DEFAULT_COLLATE_NAME = Column(String, nullable=False)

    DESCRIPTION = Column(String, nullable=False)

    MAXLEN = Column(BigInteger, nullable=False)

