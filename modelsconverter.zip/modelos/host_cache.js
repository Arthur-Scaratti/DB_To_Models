
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Host_cache = Sequelize.define('host_cache', {

    IP: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    HOST: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    HOST_VALIDATED: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    SUM_CONNECT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_HOST_BLOCKED_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_NAMEINFO_TRANSIENT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_NAMEINFO_PERMANENT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_FORMAT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_ADDRINFO_TRANSIENT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_ADDRINFO_PERMANENT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_FCRDNS_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_HOST_ACL_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_NO_AUTH_PLUGIN_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_AUTH_PLUGIN_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_HANDSHAKE_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_PROXY_USER_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_PROXY_USER_ACL_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_AUTHENTICATION_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_SSL_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_MAX_USER_CONNECTIONS_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_MAX_USER_CONNECTIONS_PER_HOUR_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_DEFAULT_DATABASE_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_INIT_CONNECT_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_LOCAL_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_UNKNOWN_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    FIRST_SEEN: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    LAST_SEEN: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    FIRST_ERROR_SEEN: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    LAST_ERROR_SEEN: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Host_cache;