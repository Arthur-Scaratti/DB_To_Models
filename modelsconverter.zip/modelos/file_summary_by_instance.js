
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const File_summary_by_instance = Sequelize.define('file_summary_by_instance', {

    FILE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    OBJECT_INSTANCE_BEGIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_STAR: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_TIMER_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_TIMER_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_TIMER_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_TIMER_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_NUMBER_OF_BYTES_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_WRITE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_TIMER_WRITE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_TIMER_WRITE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_TIMER_WRITE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_TIMER_WRITE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_NUMBER_OF_BYTES_WRITE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_MISC: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_TIMER_MISC: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_TIMER_MISC: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_TIMER_MISC: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_TIMER_MISC: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = File_summary_by_instance;