
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class CHECK_CONSTRAINTS(Base):
    __tablename__ = 'CHECK_CONSTRAINTS'

    CONSTRAINT_CATALOG = Column(String, nullable=False)

    CONSTRAINT_SCHEMA = Column(String, nullable=False)

    TABLE_NAME = Column(String, nullable=False)

    CONSTRAINT_NAME = Column(String, nullable=False)

    LEVEL = Column(String, nullable=False)

    CHECK_CLAUSE = Column(Text, nullable=False)

