
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class GLOBAL_VARIABLES
    {

        [Required]
        [StringLength(64)]
        public string? VARIABLE_NAME { get; set; }
        /// VARIABLE_NAME
        [Required]
        [StringLength(2048)]
        public string? VARIABLE_VALUE { get; set; }
        /// VARIABLE_VALUE
    }
}
