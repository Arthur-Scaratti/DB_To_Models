
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class INNODB_BUFFER_PAGE_LRU extends Model
{
    protected $table = 'INNODB_BUFFER_PAGE_LRU';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'POOL_ID',
        'LRU_POSITION',
        'SPACE',
        'PAGE_NUMBER',
        'PAGE_TYPE',
        'FLUSH_TYPE',
        'FIX_COUNT',
        'IS_HASHED',
        'NEWEST_MODIFICATION',
        'OLDEST_MODIFICATION',
        'ACCESS_TIME',
        'TABLE_NAME',
        'INDEX_NAME',
        'NUMBER_RECORDS',
        'DATA_SIZE',
        'COMPRESSED_SIZE',
        'COMPRESSED',
        'IO_FIX',
        'IS_OLD',
        'FREE_PAGE_CLOCK',

    ];
}
