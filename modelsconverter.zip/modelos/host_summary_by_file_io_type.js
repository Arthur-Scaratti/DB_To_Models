
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Host_summary_by_file_io_type = Sequelize.define('host_summary_by_file_io_type', {

    Host: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Event_name: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    Total: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Total_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Max_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Host_summary_by_file_io_type;