
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class General_log extends Model
{
    protected $table = 'general_log';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'Event_time',
        'User_host',
        'Thread_id',
        'Server_id',
        'Command_type',
        'Argument',

    ];
}
