
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class COLLATIONS extends Model
{
    protected $table = 'COLLATIONS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'COLLATION_NAME',
        'CHARACTER_SET_NAME',
        'ID',
        'IS_DEFAULT',
        'IS_COMPILED',
        'SORTLEN',

    ];
}
