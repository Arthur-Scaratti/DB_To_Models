import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class ALL_PLUGINS {
    private String PLUGIN_NAME;

     private String PLUGIN_VERSION;

     private String PLUGIN_STATUS;

     private String PLUGIN_TYPE;

     private String PLUGIN_TYPE_VERSION;

     private String PLUGIN_LIBRARY;

     private String PLUGIN_LIBRARY_VERSION;

     private String PLUGIN_AUTHOR;

     private String PLUGIN_DESCRIPTION;

     private String PLUGIN_LICENSE;

     private String LOAD_OPTION;

     private String PLUGIN_MATURITY;

     private String PLUGIN_AUTH_VERSION;

 }