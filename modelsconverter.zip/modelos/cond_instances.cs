
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Cond_instances
    {

        [Required]
        [StringLength(128)]
        public string? NAME { get; set; }
        /// NAME
        [Required]
        public long OBJECT_INSTANCE_BEGIN { get; set; }
        /// OBJECT_INSTANCE_BEGIN
    }
}
