
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Db = Sequelize.define('db', {

    Host: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Db: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    User: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Select_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Insert_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Update_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Delete_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Create_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Drop_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Grant_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    References_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Index_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Alter_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Create_tmp_table_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Lock_tables_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Create_view_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Show_view_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Create_routine_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Alter_routine_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Execute_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Event_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Trigger_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Delete_history_priv: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Db;