
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_stages_summary_by_thread_by_event_name extends Model
{
    protected $table = 'events_stages_summary_by_thread_by_event_name';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'THREAD_ID',
        'EVENT_NAME',
        'COUNT_STAR',
        'SUM_TIMER_WAIT',
        'MIN_TIMER_WAIT',
        'AVG_TIMER_WAIT',
        'MAX_TIMER_WAIT',

    ];
}
