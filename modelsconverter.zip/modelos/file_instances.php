
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class File_instances extends Model
{
    protected $table = 'file_instances';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'FILE_NAME',
        'EVENT_NAME',
        'OPEN_COUNT',

    ];
}
