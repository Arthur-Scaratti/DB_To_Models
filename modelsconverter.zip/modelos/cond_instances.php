
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Cond_instances extends Model
{
    protected $table = 'cond_instances';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'NAME',
        'OBJECT_INSTANCE_BEGIN',

    ];
}
