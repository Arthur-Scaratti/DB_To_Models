
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const CHECK_CONSTRAINTS = Sequelize.define('CHECK_CONSTRAINTS', {

    CONSTRAINT_CATALOG: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CONSTRAINT_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CONSTRAINT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    LEVEL: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CHECK_CLAUSE: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = CHECK_CONSTRAINTS;