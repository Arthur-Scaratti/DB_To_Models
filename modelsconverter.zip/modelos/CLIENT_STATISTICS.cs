
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class CLIENT_STATISTICS
    {

        [Required]
        [StringLength(64)]
        public string? CLIENT { get; set; }
        /// CLIENT
        [Required]
        public long TOTAL_CONNECTIONS { get; set; }
        /// TOTAL_CONNECTIONS
        [Required]
        public long CONCURRENT_CONNECTIONS { get; set; }
        /// CONCURRENT_CONNECTIONS
        [Required]
        public long CONNECTED_TIME { get; set; }
        /// CONNECTED_TIME
        [Required]
        public double BUSY_TIME { get; set; }
        /// BUSY_TIME
        [Required]
        public double CPU_TIME { get; set; }
        /// CPU_TIME
        [Required]
        public long BYTES_RECEIVED { get; set; }
        /// BYTES_RECEIVED
        [Required]
        public long BYTES_SENT { get; set; }
        /// BYTES_SENT
        [Required]
        public long BINLOG_BYTES_WRITTEN { get; set; }
        /// BINLOG_BYTES_WRITTEN
        [Required]
        public long ROWS_READ { get; set; }
        /// ROWS_READ
        [Required]
        public long ROWS_SENT { get; set; }
        /// ROWS_SENT
        [Required]
        public long ROWS_DELETED { get; set; }
        /// ROWS_DELETED
        [Required]
        public long ROWS_INSERTED { get; set; }
        /// ROWS_INSERTED
        [Required]
        public long ROWS_UPDATED { get; set; }
        /// ROWS_UPDATED
        [Required]
        public long SELECT_COMMANDS { get; set; }
        /// SELECT_COMMANDS
        [Required]
        public long UPDATE_COMMANDS { get; set; }
        /// UPDATE_COMMANDS
        [Required]
        public long OTHER_COMMANDS { get; set; }
        /// OTHER_COMMANDS
        [Required]
        public long COMMIT_TRANSACTIONS { get; set; }
        /// COMMIT_TRANSACTIONS
        [Required]
        public long ROLLBACK_TRANSACTIONS { get; set; }
        /// ROLLBACK_TRANSACTIONS
        [Required]
        public long DENIED_CONNECTIONS { get; set; }
        /// DENIED_CONNECTIONS
        [Required]
        public long LOST_CONNECTIONS { get; set; }
        /// LOST_CONNECTIONS
        [Required]
        public long ACCESS_DENIED { get; set; }
        /// ACCESS_DENIED
        [Required]
        public long EMPTY_QUERIES { get; set; }
        /// EMPTY_QUERIES
        [Required]
        public long TOTAL_SSL_CONNECTIONS { get; set; }
        /// TOTAL_SSL_CONNECTIONS
        [Required]
        public long MAX_STATEMENT_TIME_EXCEEDED { get; set; }
        /// MAX_STATEMENT_TIME_EXCEEDED
    }
}
