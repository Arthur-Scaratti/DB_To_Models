
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_transactions_summary_by_thread_by_event_name
    {

        [Required]
        public long THREAD_ID { get; set; }
        /// THREAD_ID
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [Required]
        public long COUNT_STAR { get; set; }
        /// COUNT_STAR
        [Required]
        public long SUM_TIMER_WAIT { get; set; }
        /// SUM_TIMER_WAIT
        [Required]
        public long MIN_TIMER_WAIT { get; set; }
        /// MIN_TIMER_WAIT
        [Required]
        public long AVG_TIMER_WAIT { get; set; }
        /// AVG_TIMER_WAIT
        [Required]
        public long MAX_TIMER_WAIT { get; set; }
        /// MAX_TIMER_WAIT
        [Required]
        public long COUNT_READ_WRITE { get; set; }
        /// COUNT_READ_WRITE
        [Required]
        public long SUM_TIMER_READ_WRITE { get; set; }
        /// SUM_TIMER_READ_WRITE
        [Required]
        public long MIN_TIMER_READ_WRITE { get; set; }
        /// MIN_TIMER_READ_WRITE
        [Required]
        public long AVG_TIMER_READ_WRITE { get; set; }
        /// AVG_TIMER_READ_WRITE
        [Required]
        public long MAX_TIMER_READ_WRITE { get; set; }
        /// MAX_TIMER_READ_WRITE
        [Required]
        public long COUNT_READ_ONLY { get; set; }
        /// COUNT_READ_ONLY
        [Required]
        public long SUM_TIMER_READ_ONLY { get; set; }
        /// SUM_TIMER_READ_ONLY
        [Required]
        public long MIN_TIMER_READ_ONLY { get; set; }
        /// MIN_TIMER_READ_ONLY
        [Required]
        public long AVG_TIMER_READ_ONLY { get; set; }
        /// AVG_TIMER_READ_ONLY
        [Required]
        public long MAX_TIMER_READ_ONLY { get; set; }
        /// MAX_TIMER_READ_ONLY
    }
}
