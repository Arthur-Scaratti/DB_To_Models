
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Capitulos
    {

        [Required]
        public int CAP_NRO { get; set; }
        /// CAP_NRO
        [Required]
        [Key]
        public int CAP_ID { get; set; }
        /// CAP_ID
        [Required]
        public int NOVEL_ID { get; set; }
        /// NOVEL_ID
        [StringLength(150)]
        public string? TITULO { get; set; }
        /// TITULO
    
        public string? CONTEUDO { get; set; }
        /// CONTEUDO
        [StringLength(50)]
        public string? NAME { get; set; }
        /// NAME
        [Required]
        [StringLength(2)]
        public string? LANGUAGE { get; set; }
        /// LANGUAGE
    }
}
