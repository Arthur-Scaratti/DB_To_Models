
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class COLLATION_CHARACTER_SET_APPLICABILITY extends Model
{
    protected $table = 'COLLATION_CHARACTER_SET_APPLICABILITY';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'COLLATION_NAME',
        'CHARACTER_SET_NAME',
        'FULL_COLLATION_NAME',
        'ID',
        'IS_DEFAULT',

    ];
}
