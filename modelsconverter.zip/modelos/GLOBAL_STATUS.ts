export interface Global_status {
    VARIABLE_NAME: string;

    VARIABLE_VALUE: string;

}