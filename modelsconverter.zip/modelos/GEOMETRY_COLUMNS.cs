
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class GEOMETRY_COLUMNS
    {

        [Required]
        [StringLength(512)]
        public string? F_TABLE_CATALOG { get; set; }
        /// F_TABLE_CATALOG
        [Required]
        [StringLength(64)]
        public string? F_TABLE_SCHEMA { get; set; }
        /// F_TABLE_SCHEMA
        [Required]
        [StringLength(64)]
        public string? F_TABLE_NAME { get; set; }
        /// F_TABLE_NAME
        [Required]
        [StringLength(64)]
        public string? F_GEOMETRY_COLUMN { get; set; }
        /// F_GEOMETRY_COLUMN
        [Required]
        [StringLength(512)]
        public string? G_TABLE_CATALOG { get; set; }
        /// G_TABLE_CATALOG
        [Required]
        [StringLength(64)]
        public string? G_TABLE_SCHEMA { get; set; }
        /// G_TABLE_SCHEMA
        [Required]
        [StringLength(64)]
        public string? G_TABLE_NAME { get; set; }
        /// G_TABLE_NAME
        [Required]
        [StringLength(64)]
        public string? G_GEOMETRY_COLUMN { get; set; }
        /// G_GEOMETRY_COLUMN
        [Required]
        public int STORAGE_TYPE { get; set; }
        /// STORAGE_TYPE
        [Required]
        public int GEOMETRY_TYPE { get; set; }
        /// GEOMETRY_TYPE
        [Required]
        public int COORD_DIMENSION { get; set; }
        /// COORD_DIMENSION
        [Required]
        public int MAX_PPR { get; set; }
        /// MAX_PPR
        [Required]
        public short SRID { get; set; }
        /// SRID
    }
}
