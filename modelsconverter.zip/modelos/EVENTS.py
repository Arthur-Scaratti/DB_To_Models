
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class EVENTS(Base):
    __tablename__ = 'EVENTS'

    EVENT_CATALOG = Column(String, nullable=False)

    EVENT_SCHEMA = Column(String, nullable=False)

    EVENT_NAME = Column(String, nullable=False)

    DEFINER = Column(String, nullable=False)

    TIME_ZONE = Column(String, nullable=False)

    EVENT_BODY = Column(String, nullable=False)

    EVENT_DEFINITION = Column(Text, nullable=False)

    EVENT_TYPE = Column(String, nullable=False)

    EXECUTE_AT = Column(DateTime)

    INTERVAL_VALUE = Column(String)

    INTERVAL_FIELD = Column(String)

    SQL_MODE = Column(String, nullable=False)

    STARTS = Column(DateTime)

    ENDS = Column(DateTime)

    STATUS = Column(String, nullable=False)

    ON_COMPLETION = Column(String, nullable=False)

    CREATED = Column(DateTime, nullable=False)

    LAST_ALTERED = Column(DateTime, nullable=False)

    LAST_EXECUTED = Column(DateTime)

    EVENT_COMMENT = Column(String, nullable=False)

    ORIGINATOR = Column(BigInteger, nullable=False)

    CHARACTER_SET_CLIENT = Column(String, nullable=False)

    COLLATION_CONNECTION = Column(String, nullable=False)

    DATABASE_COLLATION = Column(String, nullable=False)

