
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class FILES
    {

        [Required]
        public long FILE_ID { get; set; }
        /// FILE_ID
        [StringLength(512)]
        public string? FILE_NAME { get; set; }
        /// FILE_NAME
        [Required]
        [StringLength(20)]
        public string? FILE_TYPE { get; set; }
        /// FILE_TYPE
        [StringLength(64)]
        public string? TABLESPACE_NAME { get; set; }
        /// TABLESPACE_NAME
        [Required]
        [StringLength(64)]
        public string? TABLE_CATALOG { get; set; }
        /// TABLE_CATALOG
        [StringLength(64)]
        public string? TABLE_SCHEMA { get; set; }
        /// TABLE_SCHEMA
        [StringLength(64)]
        public string? TABLE_NAME { get; set; }
        /// TABLE_NAME
        [StringLength(64)]
        public string? LOGFILE_GROUP_NAME { get; set; }
        /// LOGFILE_GROUP_NAME
    
        public long LOGFILE_GROUP_NUMBER { get; set; }
        /// LOGFILE_GROUP_NUMBER
        [Required]
        [StringLength(64)]
        public string? ENGINE { get; set; }
        /// ENGINE
        [StringLength(64)]
        public string? FULLTEXT_KEYS { get; set; }
        /// FULLTEXT_KEYS
    
        public long DELETED_ROWS { get; set; }
        /// DELETED_ROWS
    
        public long UPDATE_COUNT { get; set; }
        /// UPDATE_COUNT
    
        public long FREE_EXTENTS { get; set; }
        /// FREE_EXTENTS
    
        public long TOTAL_EXTENTS { get; set; }
        /// TOTAL_EXTENTS
        [Required]
        public long EXTENT_SIZE { get; set; }
        /// EXTENT_SIZE
    
        public long INITIAL_SIZE { get; set; }
        /// INITIAL_SIZE
    
        public long MAXIMUM_SIZE { get; set; }
        /// MAXIMUM_SIZE
    
        public long AUTOEXTEND_SIZE { get; set; }
        /// AUTOEXTEND_SIZE
    
        public DateTime? CREATION_TIME { get; set; }
        /// CREATION_TIME
    
        public DateTime? LAST_UPDATE_TIME { get; set; }
        /// LAST_UPDATE_TIME
    
        public DateTime? LAST_ACCESS_TIME { get; set; }
        /// LAST_ACCESS_TIME
    
        public long RECOVER_TIME { get; set; }
        /// RECOVER_TIME
    
        public long TRANSACTION_COUNTER { get; set; }
        /// TRANSACTION_COUNTER
    
        public long VERSION { get; set; }
        /// VERSION
        [StringLength(10)]
        public string? ROW_FORMAT { get; set; }
        /// ROW_FORMAT
    
        public long TABLE_ROWS { get; set; }
        /// TABLE_ROWS
    
        public long AVG_ROW_LENGTH { get; set; }
        /// AVG_ROW_LENGTH
    
        public long DATA_LENGTH { get; set; }
        /// DATA_LENGTH
    
        public long MAX_DATA_LENGTH { get; set; }
        /// MAX_DATA_LENGTH
    
        public long INDEX_LENGTH { get; set; }
        /// INDEX_LENGTH
    
        public long DATA_FREE { get; set; }
        /// DATA_FREE
    
        public DateTime? CREATE_TIME { get; set; }
        /// CREATE_TIME
    
        public DateTime? UPDATE_TIME { get; set; }
        /// UPDATE_TIME
    
        public DateTime? CHECK_TIME { get; set; }
        /// CHECK_TIME
    
        public long CHECKSUM { get; set; }
        /// CHECKSUM
        [Required]
        [StringLength(20)]
        public string? STATUS { get; set; }
        /// STATUS
        [StringLength(255)]
        public string? EXTRA { get; set; }
        /// EXTRA
    }
}
