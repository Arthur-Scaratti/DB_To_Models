import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class host_summary {
    private String Host;

     private double Statements;

     private String Statement_latency;

     private String Statement_avg_latency;

     private double Table_scans;

     private double File_ios;

     private String File_io_latency;

     private double Current_connections;

     private double Total_connections;

     private long Unique_users;

     private String Current_memory;

     private String Total_memory_allocated;

 }