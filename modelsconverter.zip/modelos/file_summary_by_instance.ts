export interface File_summary_by_instance {
    FILE_NAME: string;

    EVENT_NAME: string;

    OBJECT_INSTANCE_BEGIN: number;

    COUNT_STAR: number;

    SUM_TIMER_WAIT: number;

    MIN_TIMER_WAIT: number;

    AVG_TIMER_WAIT: number;

    MAX_TIMER_WAIT: number;

    COUNT_READ: number;

    SUM_TIMER_READ: number;

    MIN_TIMER_READ: number;

    AVG_TIMER_READ: number;

    MAX_TIMER_READ: number;

    SUM_NUMBER_OF_BYTES_READ: number;

    COUNT_WRITE: number;

    SUM_TIMER_WRITE: number;

    MIN_TIMER_WRITE: number;

    AVG_TIMER_WRITE: number;

    MAX_TIMER_WRITE: number;

    SUM_NUMBER_OF_BYTES_WRITE: number;

    COUNT_MISC: number;

    SUM_TIMER_MISC: number;

    MIN_TIMER_MISC: number;

    AVG_TIMER_MISC: number;

    MAX_TIMER_MISC: number;

}