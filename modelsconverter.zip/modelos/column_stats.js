
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Column_stats = Sequelize.define('column_stats', {

    Db_name: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true,
    },

    Table_name: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true,
    },

    Column_name: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true,
    },

    Min_value: {
        type: DataTypes.BLOB,
        allowNull: true,
        
    },

    Max_value: {
        type: DataTypes.BLOB,
        allowNull: true,
        
    },

    Nulls_ratio: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Avg_length: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Avg_frequency: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Hist_size: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    Hist_type: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    Histogram: {
        type: DataTypes.BLOB,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Column_stats;