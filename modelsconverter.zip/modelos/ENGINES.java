import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class ENGINES {
    private String ENGINE;

     private String SUPPORT;

     private String COMMENT;

     private String TRANSACTIONS;

     private String XA;

     private String SAVEPOINTS;

 }