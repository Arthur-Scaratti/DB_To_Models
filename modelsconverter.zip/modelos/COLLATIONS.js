
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const COLLATIONS = Sequelize.define('COLLATIONS', {

    COLLATION_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CHARACTER_SET_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    IS_DEFAULT: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    IS_COMPILED: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    SORTLEN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = COLLATIONS;