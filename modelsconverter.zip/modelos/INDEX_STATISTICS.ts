export interface INDEX_STATISTICS {
    TABLE_SCHEMA: string;

    TABLE_NAME: string;

    INDEX_NAME: string;

    ROWS_READ: number;

}