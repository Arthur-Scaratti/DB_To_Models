
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Help_relation = Sequelize.define('help_relation', {

    Help_topic_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    Help_keyword_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

}, {
    timestamps: false,

});

module.exports = Help_relation;