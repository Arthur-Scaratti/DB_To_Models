
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Gtid_slave_pos extends Model
{
    protected $table = 'gtid_slave_pos';
   
    protected $primaryKey = ['Domain_id', 'Sub_id'];

    public $timestamps = false;

    protected $fillable = [
        'Domain_id',
        'Sub_id',
        'Server_id',
        'Seq_no',

    ];
}
