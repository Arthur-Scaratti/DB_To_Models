
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Host_summary_by_statement_latency(Base):
    __tablename__ = 'host_summary_by_statement_latency'

    Host = Column(String)

    Total = Column(Numeric)

    Total_latency = Column(String)

    Max_latency = Column(String)

    Lock_latency = Column(String)

    Rows_sent = Column(Numeric)

    Rows_examined = Column(Numeric)

    Rows_affected = Column(Numeric)

    Full_scans = Column(Numeric)

