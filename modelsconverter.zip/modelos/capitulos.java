import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class capitulos {
    private int CAP_NRO;

     @Id
    private int CAP_ID;

     private int NOVEL_ID;

     private String TITULO;

     private String CONTEUDO;

     private String NAME;

     private String LANGUAGE;

 }