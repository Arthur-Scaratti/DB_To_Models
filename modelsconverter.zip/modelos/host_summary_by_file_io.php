
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Host_summary_by_file_io extends Model
{
    protected $table = 'host_summary_by_file_io';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Ios',
        'Io_latency',

    ];
}
