
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_summary_by_file_io
    {

        [StringLength(255)]
        public string? Host { get; set; }
        /// host
    
        public decimal Ios { get; set; }
        /// ios
        [StringLength(12)]
        public string? Io_latency { get; set; }
        /// io_latency
    }
}
