
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Func = Sequelize.define('func', {

    Name: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Ret: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    Dl: {
        type: DataTypes.CHAR,
        allowNull: false,
        
    },

    Type: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Func;