export interface COLLATION_CHARACTER_SET_APPLICABILITY {
    COLLATION_NAME: string;

    CHARACTER_SET_NAME: string;

    FULL_COLLATION_NAME: string;

    ID: number;

    IS_DEFAULT: string;

}