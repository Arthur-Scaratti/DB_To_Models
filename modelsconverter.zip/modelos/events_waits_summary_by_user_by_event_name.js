
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Events_waits_summary_by_user_by_event_name = Sequelize.define('events_waits_summary_by_user_by_event_name', {

    USER: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COUNT_STAR: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Events_waits_summary_by_user_by_event_name;