
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Index_stats extends Model
{
    protected $table = 'index_stats';
   
    protected $primaryKey = ['Db_name', 'Table_name', 'Index_name', 'Prefix_arity'];

    public $timestamps = false;

    protected $fillable = [
        'Db_name',
        'Table_name',
        'Index_name',
        'Prefix_arity',
        'Avg_frequency',

    ];
}
