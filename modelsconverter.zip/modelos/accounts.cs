
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Accounts
    {

    
        public string? USER { get; set; }
        /// USER
    
        public string? HOST { get; set; }
        /// HOST
        [Required]
        public long CURRENT_CONNECTIONS { get; set; }
        /// CURRENT_CONNECTIONS
        [Required]
        public long TOTAL_CONNECTIONS { get; set; }
        /// TOTAL_CONNECTIONS
    }
}
