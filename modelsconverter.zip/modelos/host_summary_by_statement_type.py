
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Host_summary_by_statement_type(Base):
    __tablename__ = 'host_summary_by_statement_type'

    Host = Column(String)

    Statement = Column(String)

    Total = Column(BigInteger, nullable=False)

    Total_latency = Column(String)

    Max_latency = Column(String)

    Lock_latency = Column(String)

    Rows_sent = Column(BigInteger, nullable=False)

    Rows_examined = Column(BigInteger, nullable=False)

    Rows_affected = Column(BigInteger, nullable=False)

    Full_scans = Column(BigInteger, nullable=False)

