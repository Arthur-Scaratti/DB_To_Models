
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Event
    {

        [Required]
        [Key]
        public string? Db { get; set; }
        /// db
        [Required]
        [Key]
        public string? Name { get; set; }
        /// name
        [Required]
        public byte[]? Body { get; set; }
        /// body
        [Required]
        [StringLength(384)]
        public string? Definer { get; set; }
        /// definer
    
        public DateTime? Execute_at { get; set; }
        /// execute_at
    
        public int Interval_value { get; set; }
        /// interval_value
    
        public string? Interval_field { get; set; }
        /// interval_field
        [Required]
        public string? Created { get; set; }
        /// created
        [Required]
        public string? Modified { get; set; }
        /// modified
    
        public DateTime? Last_executed { get; set; }
        /// last_executed
    
        public DateTime? Starts { get; set; }
        /// starts
    
        public DateTime? Ends { get; set; }
        /// ends
        [Required]
        public string? Status { get; set; }
        /// status
        [Required]
        public string? On_completion { get; set; }
        /// on_completion
        [Required]
        public string? Sql_mode { get; set; }
        /// sql_mode
        [Required]
        public string? Comment { get; set; }
        /// comment
        [Required]
        public int Originator { get; set; }
        /// originator
        [Required]
        public string? Time_zone { get; set; }
        /// time_zone
    
        public string? Character_set_client { get; set; }
        /// character_set_client
    
        public string? Collation_connection { get; set; }
        /// collation_connection
    
        public string? Db_collation { get; set; }
        /// db_collation
    
        public byte[]? Body_utf8 { get; set; }
        /// body_utf8
    }
}
