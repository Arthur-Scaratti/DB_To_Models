export interface Global_priv {
    Host: string;

    User: string;

    Priv: string;

}