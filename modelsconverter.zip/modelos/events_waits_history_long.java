import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class events_waits_history_long {
    private long THREAD_ID;

     private long EVENT_ID;

     private long END_EVENT_ID;

     private String EVENT_NAME;

     private String SOURCE;

     private long TIMER_START;

     private long TIMER_END;

     private long TIMER_WAIT;

     private int SPINS;

     private String OBJECT_SCHEMA;

     private String OBJECT_NAME;

     private String INDEX_NAME;

     private String OBJECT_TYPE;

     private long OBJECT_INSTANCE_BEGIN;

     private long NESTING_EVENT_ID;

     private String NESTING_EVENT_TYPE;

     private String OPERATION;

     private long NUMBER_OF_BYTES;

     private int FLAGS;

 }