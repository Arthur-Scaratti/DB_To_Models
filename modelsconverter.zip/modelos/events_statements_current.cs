
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_statements_current
    {

        [Required]
        public long THREAD_ID { get; set; }
        /// THREAD_ID
        [Required]
        public long EVENT_ID { get; set; }
        /// EVENT_ID
    
        public long END_EVENT_ID { get; set; }
        /// END_EVENT_ID
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [StringLength(64)]
        public string? SOURCE { get; set; }
        /// SOURCE
    
        public long TIMER_START { get; set; }
        /// TIMER_START
    
        public long TIMER_END { get; set; }
        /// TIMER_END
    
        public long TIMER_WAIT { get; set; }
        /// TIMER_WAIT
        [Required]
        public long LOCK_TIME { get; set; }
        /// LOCK_TIME
    
        public string? SQL_TEXT { get; set; }
        /// SQL_TEXT
        [StringLength(32)]
        public string? DIGEST { get; set; }
        /// DIGEST
    
        public string? DIGEST_TEXT { get; set; }
        /// DIGEST_TEXT
        [StringLength(64)]
        public string? CURRENT_SCHEMA { get; set; }
        /// CURRENT_SCHEMA
        [StringLength(64)]
        public string? OBJECT_TYPE { get; set; }
        /// OBJECT_TYPE
        [StringLength(64)]
        public string? OBJECT_SCHEMA { get; set; }
        /// OBJECT_SCHEMA
        [StringLength(64)]
        public string? OBJECT_NAME { get; set; }
        /// OBJECT_NAME
    
        public long OBJECT_INSTANCE_BEGIN { get; set; }
        /// OBJECT_INSTANCE_BEGIN
    
        public int MYSQL_ERRNO { get; set; }
        /// MYSQL_ERRNO
        [StringLength(5)]
        public string? RETURNED_SQLSTATE { get; set; }
        /// RETURNED_SQLSTATE
        [StringLength(128)]
        public string? MESSAGE_TEXT { get; set; }
        /// MESSAGE_TEXT
        [Required]
        public long ERRORS { get; set; }
        /// ERRORS
        [Required]
        public long WARNINGS { get; set; }
        /// WARNINGS
        [Required]
        public long ROWS_AFFECTED { get; set; }
        /// ROWS_AFFECTED
        [Required]
        public long ROWS_SENT { get; set; }
        /// ROWS_SENT
        [Required]
        public long ROWS_EXAMINED { get; set; }
        /// ROWS_EXAMINED
        [Required]
        public long CREATED_TMP_DISK_TABLES { get; set; }
        /// CREATED_TMP_DISK_TABLES
        [Required]
        public long CREATED_TMP_TABLES { get; set; }
        /// CREATED_TMP_TABLES
        [Required]
        public long SELECT_FULL_JOIN { get; set; }
        /// SELECT_FULL_JOIN
        [Required]
        public long SELECT_FULL_RANGE_JOIN { get; set; }
        /// SELECT_FULL_RANGE_JOIN
        [Required]
        public long SELECT_RANGE { get; set; }
        /// SELECT_RANGE
        [Required]
        public long SELECT_RANGE_CHECK { get; set; }
        /// SELECT_RANGE_CHECK
        [Required]
        public long SELECT_SCAN { get; set; }
        /// SELECT_SCAN
        [Required]
        public long SORT_MERGE_PASSES { get; set; }
        /// SORT_MERGE_PASSES
        [Required]
        public long SORT_RANGE { get; set; }
        /// SORT_RANGE
        [Required]
        public long SORT_ROWS { get; set; }
        /// SORT_ROWS
        [Required]
        public long SORT_SCAN { get; set; }
        /// SORT_SCAN
        [Required]
        public long NO_INDEX_USED { get; set; }
        /// NO_INDEX_USED
        [Required]
        public long NO_GOOD_INDEX_USED { get; set; }
        /// NO_GOOD_INDEX_USED
    
        public long NESTING_EVENT_ID { get; set; }
        /// NESTING_EVENT_ID
    
        public string? NESTING_EVENT_TYPE { get; set; }
        /// NESTING_EVENT_TYPE
    
        public int NESTING_EVENT_LEVEL { get; set; }
        /// NESTING_EVENT_LEVEL
    }
}
