export interface CHARACTER_SETS {
    CHARACTER_SET_NAME: string;

    DEFAULT_COLLATE_NAME: string;

    DESCRIPTION: string;

    MAXLEN: number;

}