
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'event';
   
    protected $primaryKey = ['Db', 'Name'];

    public $timestamps = false;

    protected $fillable = [
        'Db',
        'Name',
        'Body',
        'Definer',
        'Execute_at',
        'Interval_value',
        'Interval_field',
        'Created',
        'Modified',
        'Last_executed',
        'Starts',
        'Ends',
        'Status',
        'On_completion',
        'Sql_mode',
        'Comment',
        'Originator',
        'Time_zone',
        'Character_set_client',
        'Collation_connection',
        'Db_collation',
        'Body_utf8',

    ];
}
