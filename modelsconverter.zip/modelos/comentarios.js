
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Comentarios = Sequelize.define('comentarios', {

    COMMENT_ID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    CAP_ID: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    NOVEL_ID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    CAP_NRO: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    CONTENT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    SENDER: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    RECIEVER: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    LANGUAGE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Comentarios;