
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_transactions_history extends Model
{
    protected $table = 'events_transactions_history';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'THREAD_ID',
        'EVENT_ID',
        'END_EVENT_ID',
        'EVENT_NAME',
        'STATE',
        'TRX_ID',
        'GTID',
        'XID_FORMAT_ID',
        'XID_GTRID',
        'XID_BQUAL',
        'XA_STATE',
        'SOURCE',
        'TIMER_START',
        'TIMER_END',
        'TIMER_WAIT',
        'ACCESS_MODE',
        'ISOLATION_LEVEL',
        'AUTOCOMMIT',
        'NUMBER_OF_SAVEPOINTS',
        'NUMBER_OF_ROLLBACK_TO_SAVEPOINT',
        'NUMBER_OF_RELEASE_SAVEPOINT',
        'OBJECT_INSTANCE_BEGIN',
        'NESTING_EVENT_ID',
        'NESTING_EVENT_TYPE',

    ];
}
