
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Db
    {

        [Required]
        [Key]
        public string? Host { get; set; }
        /// Host
        [Required]
        [Key]
        public string? Db { get; set; }
        /// Db
        [Required]
        [Key]
        public string? User { get; set; }
        /// User
        [Required]
        public string? Select_priv { get; set; }
        /// Select_priv
        [Required]
        public string? Insert_priv { get; set; }
        /// Insert_priv
        [Required]
        public string? Update_priv { get; set; }
        /// Update_priv
        [Required]
        public string? Delete_priv { get; set; }
        /// Delete_priv
        [Required]
        public string? Create_priv { get; set; }
        /// Create_priv
        [Required]
        public string? Drop_priv { get; set; }
        /// Drop_priv
        [Required]
        public string? Grant_priv { get; set; }
        /// Grant_priv
        [Required]
        public string? References_priv { get; set; }
        /// References_priv
        [Required]
        public string? Index_priv { get; set; }
        /// Index_priv
        [Required]
        public string? Alter_priv { get; set; }
        /// Alter_priv
        [Required]
        public string? Create_tmp_table_priv { get; set; }
        /// Create_tmp_table_priv
        [Required]
        public string? Lock_tables_priv { get; set; }
        /// Lock_tables_priv
        [Required]
        public string? Create_view_priv { get; set; }
        /// Create_view_priv
        [Required]
        public string? Show_view_priv { get; set; }
        /// Show_view_priv
        [Required]
        public string? Create_routine_priv { get; set; }
        /// Create_routine_priv
        [Required]
        public string? Alter_routine_priv { get; set; }
        /// Alter_routine_priv
        [Required]
        public string? Execute_priv { get; set; }
        /// Execute_priv
        [Required]
        public string? Event_priv { get; set; }
        /// Event_priv
        [Required]
        public string? Trigger_priv { get; set; }
        /// Trigger_priv
        [Required]
        public string? Delete_history_priv { get; set; }
        /// Delete_history_priv
    }
}
