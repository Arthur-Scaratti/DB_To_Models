import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class comentarios {
    @Id
    private int COMMENT_ID;

     private int CAP_ID;

     private int NOVEL_ID;

     private int CAP_NRO;

     private String CONTENT;

     private int SENDER;

     private int RECIEVER;

     private String LANGUAGE;

 }