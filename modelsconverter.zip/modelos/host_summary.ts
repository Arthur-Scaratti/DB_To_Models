export interface Host_summary {
    Host: string;

    Statements: number;

    Statement_latency: string;

    Statement_avg_latency: string;

    Table_scans: number;

    File_ios: number;

    File_io_latency: string;

    Current_connections: number;

    Total_connections: number;

    Unique_users: number;

    Current_memory: string;

    Total_memory_allocated: string;

}