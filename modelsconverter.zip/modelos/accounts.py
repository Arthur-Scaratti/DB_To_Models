
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Accounts(Base):
    __tablename__ = 'accounts'

    USER = Column(String)

    HOST = Column(String)

    CURRENT_CONNECTIONS = Column(BigInteger, nullable=False)

    TOTAL_CONNECTIONS = Column(BigInteger, nullable=False)

