
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Help_category(Base):
    __tablename__ = 'help_category'

    Help_category_id = Column(SmallInteger, primary_key=True, nullable=False)

    Name = Column(String, nullable=False)

    Parent_category_id = Column(SmallInteger)

    Url = Column(Text, nullable=False)

