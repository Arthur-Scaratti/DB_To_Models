export interface Events_stages_summary_by_user_by_event_name {
    USER: string;

    EVENT_NAME: string;

    COUNT_STAR: number;

    SUM_TIMER_WAIT: number;

    MIN_TIMER_WAIT: number;

    AVG_TIMER_WAIT: number;

    MAX_TIMER_WAIT: number;

}