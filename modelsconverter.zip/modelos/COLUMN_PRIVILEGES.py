
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class COLUMN_PRIVILEGES(Base):
    __tablename__ = 'COLUMN_PRIVILEGES'

    GRANTEE = Column(String, nullable=False)

    TABLE_CATALOG = Column(String, nullable=False)

    TABLE_SCHEMA = Column(String, nullable=False)

    TABLE_NAME = Column(String, nullable=False)

    COLUMN_NAME = Column(String, nullable=False)

    PRIVILEGE_TYPE = Column(String, nullable=False)

    IS_GRANTABLE = Column(String, nullable=False)

