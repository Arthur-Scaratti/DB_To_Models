
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Host_summary_by_file_io_type extends Model
{
    protected $table = 'host_summary_by_file_io_type';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Event_name',
        'Total',
        'Total_latency',
        'Max_latency',

    ];
}
