import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class host_summary_by_file_io {
    private String Host;

     private double Ios;

     private String Io_latency;

 }