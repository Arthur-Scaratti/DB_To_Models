
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Column_stats(Base):
    __tablename__ = 'column_stats'

    Db_name = Column(String, primary_key=True, nullable=False)

    Table_name = Column(String, primary_key=True, nullable=False)

    Column_name = Column(String, primary_key=True, nullable=False)

    Min_value = Column(LargeBinary)

    Max_value = Column(LargeBinary)

    Nulls_ratio = Column(Numeric)

    Avg_length = Column(Numeric)

    Avg_frequency = Column(Numeric)

    Hist_size = Column(Integer)

    Hist_type = Column(Enum)

    Histogram = Column(LargeBinary)

