export interface Index_stats {
    Db_name: string;

    Table_name: string;

    Index_name: string;

    Prefix_arity: number;

    Avg_frequency: number;

}