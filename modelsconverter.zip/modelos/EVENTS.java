import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class EVENTS {
    private String EVENT_CATALOG;

     private String EVENT_SCHEMA;

     private String EVENT_NAME;

     private String DEFINER;

     private String TIME_ZONE;

     private String EVENT_BODY;

     private String EVENT_DEFINITION;

     private String EVENT_TYPE;

     private Date EXECUTE_AT;

     private String INTERVAL_VALUE;

     private String INTERVAL_FIELD;

     private String SQL_MODE;

     private Date STARTS;

     private Date ENDS;

     private String STATUS;

     private String ON_COMPLETION;

     private Date CREATED;

     private Date LAST_ALTERED;

     private Date LAST_EXECUTED;

     private String EVENT_COMMENT;

     private long ORIGINATOR;

     private String CHARACTER_SET_CLIENT;

     private String COLLATION_CONNECTION;

     private String DATABASE_COLLATION;

 }