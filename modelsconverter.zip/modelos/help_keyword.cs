
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Help_keyword
    {

        [Required]
        [Key]
        public int Help_keyword_id { get; set; }
        /// help_keyword_id
        [Required]
        public string? Name { get; set; }
        /// name
    }
}
