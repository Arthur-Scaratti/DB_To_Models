
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const COLUMN_PRIVILEGES = Sequelize.define('COLUMN_PRIVILEGES', {

    GRANTEE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_CATALOG: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COLUMN_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PRIVILEGE_TYPE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    IS_GRANTABLE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = COLUMN_PRIVILEGES;