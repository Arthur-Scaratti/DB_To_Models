import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class events_transactions_history {
    private long THREAD_ID;

     private long EVENT_ID;

     private long END_EVENT_ID;

     private String EVENT_NAME;

     private String STATE;

     private long TRX_ID;

     private String GTID;

     private int XID_FORMAT_ID;

     private String XID_GTRID;

     private String XID_BQUAL;

     private String XA_STATE;

     private String SOURCE;

     private long TIMER_START;

     private long TIMER_END;

     private long TIMER_WAIT;

     private String ACCESS_MODE;

     private String ISOLATION_LEVEL;

     private String AUTOCOMMIT;

     private long NUMBER_OF_SAVEPOINTS;

     private long NUMBER_OF_ROLLBACK_TO_SAVEPOINT;

     private long NUMBER_OF_RELEASE_SAVEPOINT;

     private long OBJECT_INSTANCE_BEGIN;

     private long NESTING_EVENT_ID;

     private String NESTING_EVENT_TYPE;

 }