
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Global_status extends Model
{
    protected $table = 'global_status';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'VARIABLE_NAME',
        'VARIABLE_VALUE',

    ];
}
