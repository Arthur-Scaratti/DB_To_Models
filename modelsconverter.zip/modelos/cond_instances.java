import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class cond_instances {
    private String NAME;

     private long OBJECT_INSTANCE_BEGIN;

 }