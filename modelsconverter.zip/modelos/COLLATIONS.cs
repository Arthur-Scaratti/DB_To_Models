
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class COLLATIONS
    {

        [Required]
        [StringLength(64)]
        public string? COLLATION_NAME { get; set; }
        /// COLLATION_NAME
        [StringLength(32)]
        public string? CHARACTER_SET_NAME { get; set; }
        /// CHARACTER_SET_NAME
    
        public long ID { get; set; }
        /// ID
        [StringLength(3)]
        public string? IS_DEFAULT { get; set; }
        /// IS_DEFAULT
        [Required]
        [StringLength(3)]
        public string? IS_COMPILED { get; set; }
        /// IS_COMPILED
        [Required]
        public long SORTLEN { get; set; }
        /// SORTLEN
    }
}
