
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Event = Sequelize.define('event', {

    Db: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Name: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Body: {
        type: DataTypes.BLOB,
        allowNull: false,
        
    },

    Definer: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    Execute_at: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    Interval_value: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    Interval_field: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    Created: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    Modified: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    Last_executed: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    Starts: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    Ends: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    Status: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    On_completion: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    Sql_mode: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    Comment: {
        type: DataTypes.CHAR,
        allowNull: false,
        
    },

    Originator: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    Time_zone: {
        type: DataTypes.CHAR,
        allowNull: false,
        
    },

    Character_set_client: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    Collation_connection: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    Db_collation: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    Body_utf8: {
        type: DataTypes.BLOB,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Event;