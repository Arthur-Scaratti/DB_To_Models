import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class event {
    @Id
    private String Db;

     @Id
    private String Name;

     private byte[] Body;

     private String Definer;

     private Date Execute_at;

     private int Interval_value;

     private String Interval_field;

     private String Created;

     private String Modified;

     private Date Last_executed;

     private Date Starts;

     private Date Ends;

     private String Status;

     private String On_completion;

     private String Sql_mode;

     private String Comment;

     private int Originator;

     private String Time_zone;

     private String Character_set_client;

     private String Collation_connection;

     private String Db_collation;

     private byte[] Body_utf8;

 }