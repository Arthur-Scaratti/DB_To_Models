
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class INNODB_BUFFER_POOL_STATS
    {

        [Required]
        public int POOL_ID { get; set; }
        /// POOL_ID
        [Required]
        public long POOL_SIZE { get; set; }
        /// POOL_SIZE
        [Required]
        public long FREE_BUFFERS { get; set; }
        /// FREE_BUFFERS
        [Required]
        public long DATABASE_PAGES { get; set; }
        /// DATABASE_PAGES
        [Required]
        public long OLD_DATABASE_PAGES { get; set; }
        /// OLD_DATABASE_PAGES
        [Required]
        public long MODIFIED_DATABASE_PAGES { get; set; }
        /// MODIFIED_DATABASE_PAGES
        [Required]
        public long PENDING_DECOMPRESS { get; set; }
        /// PENDING_DECOMPRESS
        [Required]
        public long PENDING_READS { get; set; }
        /// PENDING_READS
        [Required]
        public long PENDING_FLUSH_LRU { get; set; }
        /// PENDING_FLUSH_LRU
        [Required]
        public long PENDING_FLUSH_LIST { get; set; }
        /// PENDING_FLUSH_LIST
        [Required]
        public long PAGES_MADE_YOUNG { get; set; }
        /// PAGES_MADE_YOUNG
        [Required]
        public long PAGES_NOT_MADE_YOUNG { get; set; }
        /// PAGES_NOT_MADE_YOUNG
        [Required]
        public float PAGES_MADE_YOUNG_RATE { get; set; }
        /// PAGES_MADE_YOUNG_RATE
        [Required]
        public float PAGES_MADE_NOT_YOUNG_RATE { get; set; }
        /// PAGES_MADE_NOT_YOUNG_RATE
        [Required]
        public long NUMBER_PAGES_READ { get; set; }
        /// NUMBER_PAGES_READ
        [Required]
        public long NUMBER_PAGES_CREATED { get; set; }
        /// NUMBER_PAGES_CREATED
        [Required]
        public long NUMBER_PAGES_WRITTEN { get; set; }
        /// NUMBER_PAGES_WRITTEN
        [Required]
        public float PAGES_READ_RATE { get; set; }
        /// PAGES_READ_RATE
        [Required]
        public float PAGES_CREATE_RATE { get; set; }
        /// PAGES_CREATE_RATE
        [Required]
        public float PAGES_WRITTEN_RATE { get; set; }
        /// PAGES_WRITTEN_RATE
        [Required]
        public long NUMBER_PAGES_GET { get; set; }
        /// NUMBER_PAGES_GET
        [Required]
        public long HIT_RATE { get; set; }
        /// HIT_RATE
        [Required]
        public long YOUNG_MAKE_PER_THOUSAND_GETS { get; set; }
        /// YOUNG_MAKE_PER_THOUSAND_GETS
        [Required]
        public long NOT_YOUNG_MAKE_PER_THOUSAND_GETS { get; set; }
        /// NOT_YOUNG_MAKE_PER_THOUSAND_GETS
        [Required]
        public long NUMBER_PAGES_READ_AHEAD { get; set; }
        /// NUMBER_PAGES_READ_AHEAD
        [Required]
        public long NUMBER_READ_AHEAD_EVICTED { get; set; }
        /// NUMBER_READ_AHEAD_EVICTED
        [Required]
        public float READ_AHEAD_RATE { get; set; }
        /// READ_AHEAD_RATE
        [Required]
        public float READ_AHEAD_EVICTED_RATE { get; set; }
        /// READ_AHEAD_EVICTED_RATE
        [Required]
        public long LRU_IO_TOTAL { get; set; }
        /// LRU_IO_TOTAL
        [Required]
        public long LRU_IO_CURRENT { get; set; }
        /// LRU_IO_CURRENT
        [Required]
        public long UNCOMPRESS_TOTAL { get; set; }
        /// UNCOMPRESS_TOTAL
        [Required]
        public long UNCOMPRESS_CURRENT { get; set; }
        /// UNCOMPRESS_CURRENT
    }
}
