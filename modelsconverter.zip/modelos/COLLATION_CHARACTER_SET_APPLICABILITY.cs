
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class COLLATION_CHARACTER_SET_APPLICABILITY
    {

        [Required]
        [StringLength(64)]
        public string? COLLATION_NAME { get; set; }
        /// COLLATION_NAME
        [Required]
        [StringLength(32)]
        public string? CHARACTER_SET_NAME { get; set; }
        /// CHARACTER_SET_NAME
        [Required]
        [StringLength(64)]
        public string? FULL_COLLATION_NAME { get; set; }
        /// FULL_COLLATION_NAME
        [Required]
        public long ID { get; set; }
        /// ID
        [Required]
        [StringLength(3)]
        public string? IS_DEFAULT { get; set; }
        /// IS_DEFAULT
    }
}
