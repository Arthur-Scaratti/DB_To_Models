
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Help_topic extends Model
{
    protected $table = 'help_topic';
   
    protected $primaryKey = ['Help_topic_id'];

    public $timestamps = false;

    protected $fillable = [
        'Help_topic_id',
        'Name',
        'Help_category_id',
        'Description',
        'Example',
        'Url',

    ];
}
