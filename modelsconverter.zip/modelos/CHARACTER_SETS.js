
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const CHARACTER_SETS = Sequelize.define('CHARACTER_SETS', {

    CHARACTER_SET_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    DEFAULT_COLLATE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    DESCRIPTION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    MAXLEN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = CHARACTER_SETS;