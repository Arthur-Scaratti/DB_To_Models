export interface Column_stats {
    Db_name: string;

    Table_name: string;

    Column_name: string;

    Min_value: any;

    Max_value: any;

    Nulls_ratio: number;

    Avg_length: number;

    Avg_frequency: number;

    Hist_size: number;

    Hist_type: string;

    Histogram: any;

}