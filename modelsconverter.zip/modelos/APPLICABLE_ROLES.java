import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class APPLICABLE_ROLES {
    private String GRANTEE;

     private String ROLE_NAME;

     private String IS_GRANTABLE;

     private String IS_DEFAULT;

 }