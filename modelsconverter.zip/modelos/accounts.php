
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Accounts extends Model
{
    protected $table = 'accounts';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'USER',
        'HOST',
        'CURRENT_CONNECTIONS',
        'TOTAL_CONNECTIONS',

    ];
}
