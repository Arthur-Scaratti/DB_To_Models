export interface COLLATIONS {
    COLLATION_NAME: string;

    CHARACTER_SET_NAME: string;

    ID: number;

    IS_DEFAULT: string;

    IS_COMPILED: string;

    SORTLEN: number;

}