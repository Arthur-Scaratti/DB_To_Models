
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Gtid_slave_pos = Sequelize.define('gtid_slave_pos', {

    Domain_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    Sub_id: {
        type: DataTypes.BIGINT,
        allowNull: false,
        primaryKey: true,
    },

    Server_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    Seq_no: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Gtid_slave_pos;