
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GLOBAL_VARIABLES extends Model
{
    protected $table = 'GLOBAL_VARIABLES';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'VARIABLE_NAME',
        'VARIABLE_VALUE',

    ];
}
