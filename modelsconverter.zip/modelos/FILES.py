
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class FILES(Base):
    __tablename__ = 'FILES'

    FILE_ID = Column(BigInteger, nullable=False)

    FILE_NAME = Column(String)

    FILE_TYPE = Column(String, nullable=False)

    TABLESPACE_NAME = Column(String)

    TABLE_CATALOG = Column(String, nullable=False)

    TABLE_SCHEMA = Column(String)

    TABLE_NAME = Column(String)

    LOGFILE_GROUP_NAME = Column(String)

    LOGFILE_GROUP_NUMBER = Column(BigInteger)

    ENGINE = Column(String, nullable=False)

    FULLTEXT_KEYS = Column(String)

    DELETED_ROWS = Column(BigInteger)

    UPDATE_COUNT = Column(BigInteger)

    FREE_EXTENTS = Column(BigInteger)

    TOTAL_EXTENTS = Column(BigInteger)

    EXTENT_SIZE = Column(BigInteger, nullable=False)

    INITIAL_SIZE = Column(BigInteger)

    MAXIMUM_SIZE = Column(BigInteger)

    AUTOEXTEND_SIZE = Column(BigInteger)

    CREATION_TIME = Column(DateTime)

    LAST_UPDATE_TIME = Column(DateTime)

    LAST_ACCESS_TIME = Column(DateTime)

    RECOVER_TIME = Column(BigInteger)

    TRANSACTION_COUNTER = Column(BigInteger)

    VERSION = Column(BigInteger)

    ROW_FORMAT = Column(String)

    TABLE_ROWS = Column(BigInteger)

    AVG_ROW_LENGTH = Column(BigInteger)

    DATA_LENGTH = Column(BigInteger)

    MAX_DATA_LENGTH = Column(BigInteger)

    INDEX_LENGTH = Column(BigInteger)

    DATA_FREE = Column(BigInteger)

    CREATE_TIME = Column(DateTime)

    UPDATE_TIME = Column(DateTime)

    CHECK_TIME = Column(DateTime)

    CHECKSUM = Column(BigInteger)

    STATUS = Column(String, nullable=False)

    EXTRA = Column(String)

