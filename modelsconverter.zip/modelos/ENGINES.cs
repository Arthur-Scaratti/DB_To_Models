
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class ENGINES
    {

        [Required]
        [StringLength(64)]
        public string? ENGINE { get; set; }
        /// ENGINE
        [Required]
        [StringLength(8)]
        public string? SUPPORT { get; set; }
        /// SUPPORT
        [Required]
        [StringLength(160)]
        public string? COMMENT { get; set; }
        /// COMMENT
        [StringLength(3)]
        public string? TRANSACTIONS { get; set; }
        /// TRANSACTIONS
        [StringLength(3)]
        public string? XA { get; set; }
        /// XA
        [StringLength(3)]
        public string? SAVEPOINTS { get; set; }
        /// SAVEPOINTS
    }
}
