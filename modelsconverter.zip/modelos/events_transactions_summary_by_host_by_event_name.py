
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Events_transactions_summary_by_host_by_event_name(Base):
    __tablename__ = 'events_transactions_summary_by_host_by_event_name'

    HOST = Column(String)

    EVENT_NAME = Column(String, nullable=False)

    COUNT_STAR = Column(BigInteger, nullable=False)

    SUM_TIMER_WAIT = Column(BigInteger, nullable=False)

    MIN_TIMER_WAIT = Column(BigInteger, nullable=False)

    AVG_TIMER_WAIT = Column(BigInteger, nullable=False)

    MAX_TIMER_WAIT = Column(BigInteger, nullable=False)

    COUNT_READ_WRITE = Column(BigInteger, nullable=False)

    SUM_TIMER_READ_WRITE = Column(BigInteger, nullable=False)

    MIN_TIMER_READ_WRITE = Column(BigInteger, nullable=False)

    AVG_TIMER_READ_WRITE = Column(BigInteger, nullable=False)

    MAX_TIMER_READ_WRITE = Column(BigInteger, nullable=False)

    COUNT_READ_ONLY = Column(BigInteger, nullable=False)

    SUM_TIMER_READ_ONLY = Column(BigInteger, nullable=False)

    MIN_TIMER_READ_ONLY = Column(BigInteger, nullable=False)

    AVG_TIMER_READ_ONLY = Column(BigInteger, nullable=False)

    MAX_TIMER_READ_ONLY = Column(BigInteger, nullable=False)

