
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const INNODB_BUFFER_PAGE_LRU = Sequelize.define('INNODB_BUFFER_PAGE_LRU', {

    POOL_ID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    LRU_POSITION: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SPACE: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    PAGE_NUMBER: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    PAGE_TYPE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    FLUSH_TYPE: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    FIX_COUNT: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    IS_HASHED: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    NEWEST_MODIFICATION: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    OLDEST_MODIFICATION: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ACCESS_TIME: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    INDEX_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    NUMBER_RECORDS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    DATA_SIZE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COMPRESSED_SIZE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COMPRESSED: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    IO_FIX: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    IS_OLD: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    FREE_PAGE_CLOCK: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = INNODB_BUFFER_PAGE_LRU;