
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Global_status = Sequelize.define('global_status', {

    VARIABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    VARIABLE_VALUE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Global_status;