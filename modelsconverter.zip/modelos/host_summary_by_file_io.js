
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Host_summary_by_file_io = Sequelize.define('host_summary_by_file_io', {

    Host: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Ios: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Io_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Host_summary_by_file_io;