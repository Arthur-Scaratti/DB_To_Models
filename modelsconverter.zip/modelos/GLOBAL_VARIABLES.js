
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const GLOBAL_VARIABLES = Sequelize.define('GLOBAL_VARIABLES', {

    VARIABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    VARIABLE_VALUE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = GLOBAL_VARIABLES;