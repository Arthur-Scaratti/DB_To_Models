
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Global_priv
    {

        [Required]
        [Key]
        public string? Host { get; set; }
        /// Host
        [Required]
        [Key]
        public string? User { get; set; }
        /// User
        [Required]
        public string? Priv { get; set; }
        /// Priv
    }
}
