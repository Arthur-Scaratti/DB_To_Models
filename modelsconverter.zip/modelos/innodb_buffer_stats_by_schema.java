import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class innodb_buffer_stats_by_schema {
    private String Object_schema;

     private String Allocated;

     private String Data;

     private long Pages;

     private long Pages_hashed;

     private long Pages_old;

     private double Rows_cached;

 }