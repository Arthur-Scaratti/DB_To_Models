import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class CLIENT_STATISTICS {
    private String CLIENT;

     private long TOTAL_CONNECTIONS;

     private long CONCURRENT_CONNECTIONS;

     private long CONNECTED_TIME;

     private double BUSY_TIME;

     private double CPU_TIME;

     private long BYTES_RECEIVED;

     private long BYTES_SENT;

     private long BINLOG_BYTES_WRITTEN;

     private long ROWS_READ;

     private long ROWS_SENT;

     private long ROWS_DELETED;

     private long ROWS_INSERTED;

     private long ROWS_UPDATED;

     private long SELECT_COMMANDS;

     private long UPDATE_COMMANDS;

     private long OTHER_COMMANDS;

     private long COMMIT_TRANSACTIONS;

     private long ROLLBACK_TRANSACTIONS;

     private long DENIED_CONNECTIONS;

     private long LOST_CONNECTIONS;

     private long ACCESS_DENIED;

     private long EMPTY_QUERIES;

     private long TOTAL_SSL_CONNECTIONS;

     private long MAX_STATEMENT_TIME_EXCEEDED;

 }