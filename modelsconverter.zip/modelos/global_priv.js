
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Global_priv = Sequelize.define('global_priv', {

    Host: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    User: {
        type: DataTypes.CHAR,
        allowNull: false,
        primaryKey: true,
    },

    Priv: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Global_priv;