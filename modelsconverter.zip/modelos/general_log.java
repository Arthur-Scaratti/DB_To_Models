import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class general_log {
    private String Event_time;

     private String User_host;

     private long Thread_id;

     private int Server_id;

     private String Command_type;

     private String Argument;

 }