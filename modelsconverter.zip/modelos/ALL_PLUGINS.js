
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const ALL_PLUGINS = Sequelize.define('ALL_PLUGINS', {

    PLUGIN_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_VERSION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_STATUS: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_TYPE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_TYPE_VERSION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_LIBRARY: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    PLUGIN_LIBRARY_VERSION: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    PLUGIN_AUTHOR: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    PLUGIN_DESCRIPTION: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

    PLUGIN_LICENSE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    LOAD_OPTION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_MATURITY: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PLUGIN_AUTH_VERSION: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = ALL_PLUGINS;