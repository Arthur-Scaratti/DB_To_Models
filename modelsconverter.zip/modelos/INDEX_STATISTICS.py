
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class INDEX_STATISTICS(Base):
    __tablename__ = 'INDEX_STATISTICS'

    TABLE_SCHEMA = Column(String, nullable=False)

    TABLE_NAME = Column(String, nullable=False)

    INDEX_NAME = Column(String, nullable=False)

    ROWS_READ = Column(BigInteger, nullable=False)

