
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_stages_history_long
    {

        [Required]
        public long THREAD_ID { get; set; }
        /// THREAD_ID
        [Required]
        public long EVENT_ID { get; set; }
        /// EVENT_ID
    
        public long END_EVENT_ID { get; set; }
        /// END_EVENT_ID
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [StringLength(64)]
        public string? SOURCE { get; set; }
        /// SOURCE
    
        public long TIMER_START { get; set; }
        /// TIMER_START
    
        public long TIMER_END { get; set; }
        /// TIMER_END
    
        public long TIMER_WAIT { get; set; }
        /// TIMER_WAIT
    
        public long WORK_COMPLETED { get; set; }
        /// WORK_COMPLETED
    
        public long WORK_ESTIMATED { get; set; }
        /// WORK_ESTIMATED
    
        public long NESTING_EVENT_ID { get; set; }
        /// NESTING_EVENT_ID
    
        public string? NESTING_EVENT_TYPE { get; set; }
        /// NESTING_EVENT_TYPE
    }
}
