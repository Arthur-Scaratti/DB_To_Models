import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class help_topic {
    @Id
    private int Help_topic_id;

     private String Name;

     private short Help_category_id;

     private String Description;

     private String Example;

     private String Url;

 }