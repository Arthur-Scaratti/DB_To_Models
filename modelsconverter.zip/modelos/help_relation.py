
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Help_relation(Base):
    __tablename__ = 'help_relation'

    Help_topic_id = Column(Integer, primary_key=True, nullable=False)

    Help_keyword_id = Column(Integer, primary_key=True, nullable=False)

