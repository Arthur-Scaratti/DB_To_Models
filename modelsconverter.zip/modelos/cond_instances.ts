export interface Cond_instances {
    NAME: string;

    OBJECT_INSTANCE_BEGIN: number;

}