export interface Capitulos {
    CAP_NRO: number;

    CAP_ID: number;

    NOVEL_ID: number;

    TITULO: string;

    CONTEUDO: string;

    NAME: string;

    LANGUAGE: string;

}