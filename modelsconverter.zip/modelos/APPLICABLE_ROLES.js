
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const APPLICABLE_ROLES = Sequelize.define('APPLICABLE_ROLES', {

    GRANTEE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    ROLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    IS_GRANTABLE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    IS_DEFAULT: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = APPLICABLE_ROLES;