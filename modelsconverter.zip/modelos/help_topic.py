
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Help_topic(Base):
    __tablename__ = 'help_topic'

    Help_topic_id = Column(Integer, primary_key=True, nullable=False)

    Name = Column(String, nullable=False)

    Help_category_id = Column(SmallInteger, nullable=False)

    Description = Column(Text, nullable=False)

    Example = Column(Text, nullable=False)

    Url = Column(Text, nullable=False)

