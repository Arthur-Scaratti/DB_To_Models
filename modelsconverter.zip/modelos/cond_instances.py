
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Cond_instances(Base):
    __tablename__ = 'cond_instances'

    NAME = Column(String, nullable=False)

    OBJECT_INSTANCE_BEGIN = Column(BigInteger, nullable=False)

