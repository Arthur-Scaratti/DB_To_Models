export interface Columns_priv {
    Host: string;

    Db: string;

    User: string;

    Table_name: string;

    Column_name: string;

    Timestamp: string;

    Column_priv: string;

}