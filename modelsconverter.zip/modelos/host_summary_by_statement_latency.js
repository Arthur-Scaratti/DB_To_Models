
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Host_summary_by_statement_latency = Sequelize.define('host_summary_by_statement_latency', {

    Host: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Total: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Total_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Max_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Lock_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Rows_sent: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Rows_examined: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Rows_affected: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Full_scans: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Host_summary_by_statement_latency;