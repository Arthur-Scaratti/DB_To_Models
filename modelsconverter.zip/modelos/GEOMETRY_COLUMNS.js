
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const GEOMETRY_COLUMNS = Sequelize.define('GEOMETRY_COLUMNS', {

    F_TABLE_CATALOG: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    F_TABLE_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    F_TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    F_GEOMETRY_COLUMN: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    G_TABLE_CATALOG: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    G_TABLE_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    G_TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    G_GEOMETRY_COLUMN: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    STORAGE_TYPE: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    GEOMETRY_TYPE: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    COORD_DIMENSION: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    MAX_PPR: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    SRID: {
        type: DataTypes.SMALLINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = GEOMETRY_COLUMNS;