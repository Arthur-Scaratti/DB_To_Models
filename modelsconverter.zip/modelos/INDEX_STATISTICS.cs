
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class INDEX_STATISTICS
    {

        [Required]
        [StringLength(192)]
        public string? TABLE_SCHEMA { get; set; }
        /// TABLE_SCHEMA
        [Required]
        [StringLength(192)]
        public string? TABLE_NAME { get; set; }
        /// TABLE_NAME
        [Required]
        [StringLength(192)]
        public string? INDEX_NAME { get; set; }
        /// INDEX_NAME
        [Required]
        public long ROWS_READ { get; set; }
        /// ROWS_READ
    }
}
