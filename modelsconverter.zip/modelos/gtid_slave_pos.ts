export interface Gtid_slave_pos {
    Domain_id: number;

    Sub_id: number;

    Server_id: number;

    Seq_no: number;

}