
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const COLUMNS = Sequelize.define('COLUMNS', {

    TABLE_CATALOG: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COLUMN_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    ORDINAL_POSITION: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COLUMN_DEFAULT: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

    IS_NULLABLE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    DATA_TYPE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CHARACTER_MAXIMUM_LENGTH: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    CHARACTER_OCTET_LENGTH: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NUMERIC_PRECISION: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NUMERIC_SCALE: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    DATETIME_PRECISION: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    CHARACTER_SET_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    COLLATION_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    COLUMN_TYPE: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

    COLUMN_KEY: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EXTRA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    PRIVILEGES: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COLUMN_COMMENT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    IS_GENERATED: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    GENERATION_EXPRESSION: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = COLUMNS;