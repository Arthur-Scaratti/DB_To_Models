
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class ALL_PLUGINS(Base):
    __tablename__ = 'ALL_PLUGINS'

    PLUGIN_NAME = Column(String, nullable=False)

    PLUGIN_VERSION = Column(String, nullable=False)

    PLUGIN_STATUS = Column(String, nullable=False)

    PLUGIN_TYPE = Column(String, nullable=False)

    PLUGIN_TYPE_VERSION = Column(String, nullable=False)

    PLUGIN_LIBRARY = Column(String)

    PLUGIN_LIBRARY_VERSION = Column(String)

    PLUGIN_AUTHOR = Column(String)

    PLUGIN_DESCRIPTION = Column(Text)

    PLUGIN_LICENSE = Column(String, nullable=False)

    LOAD_OPTION = Column(String, nullable=False)

    PLUGIN_MATURITY = Column(String, nullable=False)

    PLUGIN_AUTH_VERSION = Column(String)

