
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Help_relation extends Model
{
    protected $table = 'help_relation';
   
    protected $primaryKey = ['Help_topic_id', 'Help_keyword_id'];

    public $timestamps = false;

    protected $fillable = [
        'Help_topic_id',
        'Help_keyword_id',

    ];
}
