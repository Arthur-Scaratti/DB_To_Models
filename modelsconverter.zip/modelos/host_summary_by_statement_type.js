
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Host_summary_by_statement_type = Sequelize.define('host_summary_by_statement_type', {

    Host: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Statement: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Total: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Total_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Max_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Lock_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Rows_sent: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Rows_examined: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Rows_affected: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Full_scans: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Host_summary_by_statement_type;