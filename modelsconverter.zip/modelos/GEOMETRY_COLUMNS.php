
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class GEOMETRY_COLUMNS extends Model
{
    protected $table = 'GEOMETRY_COLUMNS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'F_TABLE_CATALOG',
        'F_TABLE_SCHEMA',
        'F_TABLE_NAME',
        'F_GEOMETRY_COLUMN',
        'G_TABLE_CATALOG',
        'G_TABLE_SCHEMA',
        'G_TABLE_NAME',
        'G_GEOMETRY_COLUMN',
        'STORAGE_TYPE',
        'GEOMETRY_TYPE',
        'COORD_DIMENSION',
        'MAX_PPR',
        'SRID',

    ];
}
