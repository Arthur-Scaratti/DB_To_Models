import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class GEOMETRY_COLUMNS {
    private String F_TABLE_CATALOG;

     private String F_TABLE_SCHEMA;

     private String F_TABLE_NAME;

     private String F_GEOMETRY_COLUMN;

     private String G_TABLE_CATALOG;

     private String G_TABLE_SCHEMA;

     private String G_TABLE_NAME;

     private String G_GEOMETRY_COLUMN;

     private int STORAGE_TYPE;

     private int GEOMETRY_TYPE;

     private int COORD_DIMENSION;

     private int MAX_PPR;

     private short SRID;

 }