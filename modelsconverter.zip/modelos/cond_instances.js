
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Cond_instances = Sequelize.define('cond_instances', {

    NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    OBJECT_INSTANCE_BEGIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Cond_instances;