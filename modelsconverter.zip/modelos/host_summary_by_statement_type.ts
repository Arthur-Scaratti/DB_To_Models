export interface Host_summary_by_statement_type {
    Host: string;

    Statement: string;

    Total: number;

    Total_latency: string;

    Max_latency: string;

    Lock_latency: string;

    Rows_sent: number;

    Rows_examined: number;

    Rows_affected: number;

    Full_scans: number;

}