export interface Host_summary_by_file_io_type {
    Host: string;

    Event_name: string;

    Total: number;

    Total_latency: string;

    Max_latency: string;

}