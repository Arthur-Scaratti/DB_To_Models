
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Capitulos = Sequelize.define('capitulos', {

    CAP_NRO: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    CAP_ID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    NOVEL_ID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    TITULO: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    CONTEUDO: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

    NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    LANGUAGE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Capitulos;