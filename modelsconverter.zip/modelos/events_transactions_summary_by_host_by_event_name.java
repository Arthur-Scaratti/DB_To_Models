import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class events_transactions_summary_by_host_by_event_name {
    private String HOST;

     private String EVENT_NAME;

     private long COUNT_STAR;

     private long SUM_TIMER_WAIT;

     private long MIN_TIMER_WAIT;

     private long AVG_TIMER_WAIT;

     private long MAX_TIMER_WAIT;

     private long COUNT_READ_WRITE;

     private long SUM_TIMER_READ_WRITE;

     private long MIN_TIMER_READ_WRITE;

     private long AVG_TIMER_READ_WRITE;

     private long MAX_TIMER_READ_WRITE;

     private long COUNT_READ_ONLY;

     private long SUM_TIMER_READ_ONLY;

     private long MIN_TIMER_READ_ONLY;

     private long AVG_TIMER_READ_ONLY;

     private long MAX_TIMER_READ_ONLY;

 }