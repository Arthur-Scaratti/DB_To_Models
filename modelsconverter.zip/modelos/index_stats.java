import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class index_stats {
    @Id
    private String Db_name;

     @Id
    private String Table_name;

     @Id
    private String Index_name;

     @Id
    private int Prefix_arity;

     private double Avg_frequency;

 }