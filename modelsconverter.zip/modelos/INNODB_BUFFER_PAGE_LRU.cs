
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class INNODB_BUFFER_PAGE_LRU
    {

        [Required]
        public int POOL_ID { get; set; }
        /// POOL_ID
        [Required]
        public long LRU_POSITION { get; set; }
        /// LRU_POSITION
        [Required]
        public int SPACE { get; set; }
        /// SPACE
        [Required]
        public int PAGE_NUMBER { get; set; }
        /// PAGE_NUMBER
        [StringLength(64)]
        public string? PAGE_TYPE { get; set; }
        /// PAGE_TYPE
        [Required]
        public int FLUSH_TYPE { get; set; }
        /// FLUSH_TYPE
        [Required]
        public int FIX_COUNT { get; set; }
        /// FIX_COUNT
        [Required]
        public int IS_HASHED { get; set; }
        /// IS_HASHED
        [Required]
        public long NEWEST_MODIFICATION { get; set; }
        /// NEWEST_MODIFICATION
        [Required]
        public long OLDEST_MODIFICATION { get; set; }
        /// OLDEST_MODIFICATION
        [Required]
        public long ACCESS_TIME { get; set; }
        /// ACCESS_TIME
        [StringLength(1024)]
        public string? TABLE_NAME { get; set; }
        /// TABLE_NAME
        [StringLength(64)]
        public string? INDEX_NAME { get; set; }
        /// INDEX_NAME
        [Required]
        public long NUMBER_RECORDS { get; set; }
        /// NUMBER_RECORDS
        [Required]
        public long DATA_SIZE { get; set; }
        /// DATA_SIZE
        [Required]
        public long COMPRESSED_SIZE { get; set; }
        /// COMPRESSED_SIZE
        [Required]
        public int COMPRESSED { get; set; }
        /// COMPRESSED
        [Required]
        public string? IO_FIX { get; set; }
        /// IO_FIX
    
        public int IS_OLD { get; set; }
        /// IS_OLD
        [Required]
        public long FREE_PAGE_CLOCK { get; set; }
        /// FREE_PAGE_CLOCK
    }
}
