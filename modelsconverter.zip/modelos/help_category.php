
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Help_category extends Model
{
    protected $table = 'help_category';
   
    protected $primaryKey = ['Help_category_id'];

    public $timestamps = false;

    protected $fillable = [
        'Help_category_id',
        'Name',
        'Parent_category_id',
        'Url',

    ];
}
