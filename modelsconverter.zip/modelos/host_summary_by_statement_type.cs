
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_summary_by_statement_type
    {

        [StringLength(255)]
        public string? Host { get; set; }
        /// host
        [StringLength(128)]
        public string? Statement { get; set; }
        /// statement
        [Required]
        public long Total { get; set; }
        /// total
        [StringLength(12)]
        public string? Total_latency { get; set; }
        /// total_latency
        [StringLength(12)]
        public string? Max_latency { get; set; }
        /// max_latency
        [StringLength(12)]
        public string? Lock_latency { get; set; }
        /// lock_latency
        [Required]
        public long Rows_sent { get; set; }
        /// rows_sent
        [Required]
        public long Rows_examined { get; set; }
        /// rows_examined
        [Required]
        public long Rows_affected { get; set; }
        /// rows_affected
        [Required]
        public long Full_scans { get; set; }
        /// full_scans
    }
}
