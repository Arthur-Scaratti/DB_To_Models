
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_transactions_summary_global_by_event_name extends Model
{
    protected $table = 'events_transactions_summary_global_by_event_name';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'EVENT_NAME',
        'COUNT_STAR',
        'SUM_TIMER_WAIT',
        'MIN_TIMER_WAIT',
        'AVG_TIMER_WAIT',
        'MAX_TIMER_WAIT',
        'COUNT_READ_WRITE',
        'SUM_TIMER_READ_WRITE',
        'MIN_TIMER_READ_WRITE',
        'AVG_TIMER_READ_WRITE',
        'MAX_TIMER_READ_WRITE',
        'COUNT_READ_ONLY',
        'SUM_TIMER_READ_ONLY',
        'MIN_TIMER_READ_ONLY',
        'AVG_TIMER_READ_ONLY',
        'MAX_TIMER_READ_ONLY',

    ];
}
