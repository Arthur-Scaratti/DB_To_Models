export interface Host_summary_by_file_io {
    Host: string;

    Ios: number;

    Io_latency: string;

}