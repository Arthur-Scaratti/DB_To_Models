
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class INNODB_BUFFER_PAGE_LRU(Base):
    __tablename__ = 'INNODB_BUFFER_PAGE_LRU'

    POOL_ID = Column(Integer, nullable=False)

    LRU_POSITION = Column(BigInteger, nullable=False)

    SPACE = Column(Integer, nullable=False)

    PAGE_NUMBER = Column(Integer, nullable=False)

    PAGE_TYPE = Column(String)

    FLUSH_TYPE = Column(Integer, nullable=False)

    FIX_COUNT = Column(Integer, nullable=False)

    IS_HASHED = Column(Integer, nullable=False)

    NEWEST_MODIFICATION = Column(BigInteger, nullable=False)

    OLDEST_MODIFICATION = Column(BigInteger, nullable=False)

    ACCESS_TIME = Column(BigInteger, nullable=False)

    TABLE_NAME = Column(String)

    INDEX_NAME = Column(String)

    NUMBER_RECORDS = Column(BigInteger, nullable=False)

    DATA_SIZE = Column(BigInteger, nullable=False)

    COMPRESSED_SIZE = Column(BigInteger, nullable=False)

    COMPRESSED = Column(Integer, nullable=False)

    IO_FIX = Column(Enum, nullable=False)

    IS_OLD = Column(Integer)

    FREE_PAGE_CLOCK = Column(BigInteger, nullable=False)

