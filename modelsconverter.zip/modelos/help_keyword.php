
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Help_keyword extends Model
{
    protected $table = 'help_keyword';
   
    protected $primaryKey = ['Help_keyword_id'];

    public $timestamps = false;

    protected $fillable = [
        'Help_keyword_id',
        'Name',

    ];
}
