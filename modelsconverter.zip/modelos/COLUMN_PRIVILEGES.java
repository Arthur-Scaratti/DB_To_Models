import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class COLUMN_PRIVILEGES {
    private String GRANTEE;

     private String TABLE_CATALOG;

     private String TABLE_SCHEMA;

     private String TABLE_NAME;

     private String COLUMN_NAME;

     private String PRIVILEGE_TYPE;

     private String IS_GRANTABLE;

 }