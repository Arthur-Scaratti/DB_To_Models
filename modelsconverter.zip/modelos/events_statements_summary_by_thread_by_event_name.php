
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_statements_summary_by_thread_by_event_name extends Model
{
    protected $table = 'events_statements_summary_by_thread_by_event_name';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'THREAD_ID',
        'EVENT_NAME',
        'COUNT_STAR',
        'SUM_TIMER_WAIT',
        'MIN_TIMER_WAIT',
        'AVG_TIMER_WAIT',
        'MAX_TIMER_WAIT',
        'SUM_LOCK_TIME',
        'SUM_ERRORS',
        'SUM_WARNINGS',
        'SUM_ROWS_AFFECTED',
        'SUM_ROWS_SENT',
        'SUM_ROWS_EXAMINED',
        'SUM_CREATED_TMP_DISK_TABLES',
        'SUM_CREATED_TMP_TABLES',
        'SUM_SELECT_FULL_JOIN',
        'SUM_SELECT_FULL_RANGE_JOIN',
        'SUM_SELECT_RANGE',
        'SUM_SELECT_RANGE_CHECK',
        'SUM_SELECT_SCAN',
        'SUM_SORT_MERGE_PASSES',
        'SUM_SORT_RANGE',
        'SUM_SORT_ROWS',
        'SUM_SORT_SCAN',
        'SUM_NO_INDEX_USED',
        'SUM_NO_GOOD_INDEX_USED',

    ];
}
