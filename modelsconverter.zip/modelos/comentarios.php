
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Comentarios extends Model
{
    protected $table = 'comentarios';
   
    protected $primaryKey = ['COMMENT_ID'];

    public $timestamps = false;

    protected $fillable = [
        'COMMENT_ID',
        'CAP_ID',
        'NOVEL_ID',
        'CAP_NRO',
        'CONTENT',
        'SENDER',
        'RECIEVER',
        'LANGUAGE',

    ];
}
