export interface Help_keyword {
    Help_keyword_id: number;

    Name: string;

}