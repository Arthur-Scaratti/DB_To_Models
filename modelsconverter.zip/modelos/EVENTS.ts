export interface EVENTS {
    EVENT_CATALOG: string;

    EVENT_SCHEMA: string;

    EVENT_NAME: string;

    DEFINER: string;

    TIME_ZONE: string;

    EVENT_BODY: string;

    EVENT_DEFINITION: string;

    EVENT_TYPE: string;

    EXECUTE_AT: Date;

    INTERVAL_VALUE: string;

    INTERVAL_FIELD: string;

    SQL_MODE: string;

    STARTS: Date;

    ENDS: Date;

    STATUS: string;

    ON_COMPLETION: string;

    CREATED: Date;

    LAST_ALTERED: Date;

    LAST_EXECUTED: Date;

    EVENT_COMMENT: string;

    ORIGINATOR: number;

    CHARACTER_SET_CLIENT: string;

    COLLATION_CONNECTION: string;

    DATABASE_COLLATION: string;

}