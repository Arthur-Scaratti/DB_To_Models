
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class COLUMN_PRIVILEGES
    {

        [Required]
        [StringLength(385)]
        public string? GRANTEE { get; set; }
        /// GRANTEE
        [Required]
        [StringLength(512)]
        public string? TABLE_CATALOG { get; set; }
        /// TABLE_CATALOG
        [Required]
        [StringLength(64)]
        public string? TABLE_SCHEMA { get; set; }
        /// TABLE_SCHEMA
        [Required]
        [StringLength(64)]
        public string? TABLE_NAME { get; set; }
        /// TABLE_NAME
        [Required]
        [StringLength(64)]
        public string? COLUMN_NAME { get; set; }
        /// COLUMN_NAME
        [Required]
        [StringLength(64)]
        public string? PRIVILEGE_TYPE { get; set; }
        /// PRIVILEGE_TYPE
        [Required]
        [StringLength(3)]
        public string? IS_GRANTABLE { get; set; }
        /// IS_GRANTABLE
    }
}
