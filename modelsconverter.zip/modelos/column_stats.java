import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class column_stats {
    @Id
    private String Db_name;

     @Id
    private String Table_name;

     @Id
    private String Column_name;

     private byte[] Min_value;

     private byte[] Max_value;

     private double Nulls_ratio;

     private double Avg_length;

     private double Avg_frequency;

     private int Hist_size;

     private String Hist_type;

     private byte[] Histogram;

 }