
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Help_keyword = Sequelize.define('help_keyword', {

    Help_keyword_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    Name: {
        type: DataTypes.CHAR,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Help_keyword;