import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class func {
    @Id
    private String Name;

     private int Ret;

     private String Dl;

     private String Type;

 }