
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_statements_summary_by_host_by_event_name
    {

    
        public string? HOST { get; set; }
        /// HOST
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [Required]
        public long COUNT_STAR { get; set; }
        /// COUNT_STAR
        [Required]
        public long SUM_TIMER_WAIT { get; set; }
        /// SUM_TIMER_WAIT
        [Required]
        public long MIN_TIMER_WAIT { get; set; }
        /// MIN_TIMER_WAIT
        [Required]
        public long AVG_TIMER_WAIT { get; set; }
        /// AVG_TIMER_WAIT
        [Required]
        public long MAX_TIMER_WAIT { get; set; }
        /// MAX_TIMER_WAIT
        [Required]
        public long SUM_LOCK_TIME { get; set; }
        /// SUM_LOCK_TIME
        [Required]
        public long SUM_ERRORS { get; set; }
        /// SUM_ERRORS
        [Required]
        public long SUM_WARNINGS { get; set; }
        /// SUM_WARNINGS
        [Required]
        public long SUM_ROWS_AFFECTED { get; set; }
        /// SUM_ROWS_AFFECTED
        [Required]
        public long SUM_ROWS_SENT { get; set; }
        /// SUM_ROWS_SENT
        [Required]
        public long SUM_ROWS_EXAMINED { get; set; }
        /// SUM_ROWS_EXAMINED
        [Required]
        public long SUM_CREATED_TMP_DISK_TABLES { get; set; }
        /// SUM_CREATED_TMP_DISK_TABLES
        [Required]
        public long SUM_CREATED_TMP_TABLES { get; set; }
        /// SUM_CREATED_TMP_TABLES
        [Required]
        public long SUM_SELECT_FULL_JOIN { get; set; }
        /// SUM_SELECT_FULL_JOIN
        [Required]
        public long SUM_SELECT_FULL_RANGE_JOIN { get; set; }
        /// SUM_SELECT_FULL_RANGE_JOIN
        [Required]
        public long SUM_SELECT_RANGE { get; set; }
        /// SUM_SELECT_RANGE
        [Required]
        public long SUM_SELECT_RANGE_CHECK { get; set; }
        /// SUM_SELECT_RANGE_CHECK
        [Required]
        public long SUM_SELECT_SCAN { get; set; }
        /// SUM_SELECT_SCAN
        [Required]
        public long SUM_SORT_MERGE_PASSES { get; set; }
        /// SUM_SORT_MERGE_PASSES
        [Required]
        public long SUM_SORT_RANGE { get; set; }
        /// SUM_SORT_RANGE
        [Required]
        public long SUM_SORT_ROWS { get; set; }
        /// SUM_SORT_ROWS
        [Required]
        public long SUM_SORT_SCAN { get; set; }
        /// SUM_SORT_SCAN
        [Required]
        public long SUM_NO_INDEX_USED { get; set; }
        /// SUM_NO_INDEX_USED
        [Required]
        public long SUM_NO_GOOD_INDEX_USED { get; set; }
        /// SUM_NO_GOOD_INDEX_USED
    }
}
