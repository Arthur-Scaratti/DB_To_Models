
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Events_statements_current(Base):
    __tablename__ = 'events_statements_current'

    THREAD_ID = Column(BigInteger, nullable=False)

    EVENT_ID = Column(BigInteger, nullable=False)

    END_EVENT_ID = Column(BigInteger)

    EVENT_NAME = Column(String, nullable=False)

    SOURCE = Column(String)

    TIMER_START = Column(BigInteger)

    TIMER_END = Column(BigInteger)

    TIMER_WAIT = Column(BigInteger)

    LOCK_TIME = Column(BigInteger, nullable=False)

    SQL_TEXT = Column(Text)

    DIGEST = Column(String)

    DIGEST_TEXT = Column(Text)

    CURRENT_SCHEMA = Column(String)

    OBJECT_TYPE = Column(String)

    OBJECT_SCHEMA = Column(String)

    OBJECT_NAME = Column(String)

    OBJECT_INSTANCE_BEGIN = Column(BigInteger)

    MYSQL_ERRNO = Column(Integer)

    RETURNED_SQLSTATE = Column(String)

    MESSAGE_TEXT = Column(String)

    ERRORS = Column(BigInteger, nullable=False)

    WARNINGS = Column(BigInteger, nullable=False)

    ROWS_AFFECTED = Column(BigInteger, nullable=False)

    ROWS_SENT = Column(BigInteger, nullable=False)

    ROWS_EXAMINED = Column(BigInteger, nullable=False)

    CREATED_TMP_DISK_TABLES = Column(BigInteger, nullable=False)

    CREATED_TMP_TABLES = Column(BigInteger, nullable=False)

    SELECT_FULL_JOIN = Column(BigInteger, nullable=False)

    SELECT_FULL_RANGE_JOIN = Column(BigInteger, nullable=False)

    SELECT_RANGE = Column(BigInteger, nullable=False)

    SELECT_RANGE_CHECK = Column(BigInteger, nullable=False)

    SELECT_SCAN = Column(BigInteger, nullable=False)

    SORT_MERGE_PASSES = Column(BigInteger, nullable=False)

    SORT_RANGE = Column(BigInteger, nullable=False)

    SORT_ROWS = Column(BigInteger, nullable=False)

    SORT_SCAN = Column(BigInteger, nullable=False)

    NO_INDEX_USED = Column(BigInteger, nullable=False)

    NO_GOOD_INDEX_USED = Column(BigInteger, nullable=False)

    NESTING_EVENT_ID = Column(BigInteger)

    NESTING_EVENT_TYPE = Column(Enum)

    NESTING_EVENT_LEVEL = Column(Integer)

