
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Comentarios(Base):
    __tablename__ = 'comentarios'

    COMMENT_ID = Column(Integer, primary_key=True, nullable=False)

    CAP_ID = Column(Integer)

    NOVEL_ID = Column(Integer, nullable=False)

    CAP_NRO = Column(Integer)

    CONTENT = Column(String, nullable=False)

    SENDER = Column(Integer)

    RECIEVER = Column(Integer)

    LANGUAGE = Column(String)

