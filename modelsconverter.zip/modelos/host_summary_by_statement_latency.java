import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class host_summary_by_statement_latency {
    private String Host;

     private double Total;

     private String Total_latency;

     private String Max_latency;

     private String Lock_latency;

     private double Rows_sent;

     private double Rows_examined;

     private double Rows_affected;

     private double Full_scans;

 }