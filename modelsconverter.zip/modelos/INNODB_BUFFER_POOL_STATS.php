
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class INNODB_BUFFER_POOL_STATS extends Model
{
    protected $table = 'INNODB_BUFFER_POOL_STATS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'POOL_ID',
        'POOL_SIZE',
        'FREE_BUFFERS',
        'DATABASE_PAGES',
        'OLD_DATABASE_PAGES',
        'MODIFIED_DATABASE_PAGES',
        'PENDING_DECOMPRESS',
        'PENDING_READS',
        'PENDING_FLUSH_LRU',
        'PENDING_FLUSH_LIST',
        'PAGES_MADE_YOUNG',
        'PAGES_NOT_MADE_YOUNG',
        'PAGES_MADE_YOUNG_RATE',
        'PAGES_MADE_NOT_YOUNG_RATE',
        'NUMBER_PAGES_READ',
        'NUMBER_PAGES_CREATED',
        'NUMBER_PAGES_WRITTEN',
        'PAGES_READ_RATE',
        'PAGES_CREATE_RATE',
        'PAGES_WRITTEN_RATE',
        'NUMBER_PAGES_GET',
        'HIT_RATE',
        'YOUNG_MAKE_PER_THOUSAND_GETS',
        'NOT_YOUNG_MAKE_PER_THOUSAND_GETS',
        'NUMBER_PAGES_READ_AHEAD',
        'NUMBER_READ_AHEAD_EVICTED',
        'READ_AHEAD_RATE',
        'READ_AHEAD_EVICTED_RATE',
        'LRU_IO_TOTAL',
        'LRU_IO_CURRENT',
        'UNCOMPRESS_TOTAL',
        'UNCOMPRESS_CURRENT',

    ];
}
