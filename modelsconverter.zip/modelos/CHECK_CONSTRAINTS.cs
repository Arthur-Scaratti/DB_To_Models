
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class CHECK_CONSTRAINTS
    {

        [Required]
        [StringLength(512)]
        public string? CONSTRAINT_CATALOG { get; set; }
        /// CONSTRAINT_CATALOG
        [Required]
        [StringLength(64)]
        public string? CONSTRAINT_SCHEMA { get; set; }
        /// CONSTRAINT_SCHEMA
        [Required]
        [StringLength(64)]
        public string? TABLE_NAME { get; set; }
        /// TABLE_NAME
        [Required]
        [StringLength(64)]
        public string? CONSTRAINT_NAME { get; set; }
        /// CONSTRAINT_NAME
        [Required]
        [StringLength(6)]
        public string? LEVEL { get; set; }
        /// LEVEL
        [Required]
        public string? CHECK_CLAUSE { get; set; }
        /// CHECK_CLAUSE
    }
}
