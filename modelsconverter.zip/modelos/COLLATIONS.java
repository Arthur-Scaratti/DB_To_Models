import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class COLLATIONS {
    private String COLLATION_NAME;

     private String CHARACTER_SET_NAME;

     private long ID;

     private String IS_DEFAULT;

     private String IS_COMPILED;

     private long SORTLEN;

 }