
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_summary_by_statement_latency
    {

        [StringLength(255)]
        public string? Host { get; set; }
        /// host
    
        public decimal Total { get; set; }
        /// total
        [StringLength(12)]
        public string? Total_latency { get; set; }
        /// total_latency
        [StringLength(12)]
        public string? Max_latency { get; set; }
        /// max_latency
        [StringLength(12)]
        public string? Lock_latency { get; set; }
        /// lock_latency
    
        public decimal Rows_sent { get; set; }
        /// rows_sent
    
        public decimal Rows_examined { get; set; }
        /// rows_examined
    
        public decimal Rows_affected { get; set; }
        /// rows_affected
    
        public decimal Full_scans { get; set; }
        /// full_scans
    }
}
