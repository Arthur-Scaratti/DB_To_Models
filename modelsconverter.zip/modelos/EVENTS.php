
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EVENTS extends Model
{
    protected $table = 'EVENTS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'EVENT_CATALOG',
        'EVENT_SCHEMA',
        'EVENT_NAME',
        'DEFINER',
        'TIME_ZONE',
        'EVENT_BODY',
        'EVENT_DEFINITION',
        'EVENT_TYPE',
        'EXECUTE_AT',
        'INTERVAL_VALUE',
        'INTERVAL_FIELD',
        'SQL_MODE',
        'STARTS',
        'ENDS',
        'STATUS',
        'ON_COMPLETION',
        'CREATED',
        'LAST_ALTERED',
        'LAST_EXECUTED',
        'EVENT_COMMENT',
        'ORIGINATOR',
        'CHARACTER_SET_CLIENT',
        'COLLATION_CONNECTION',
        'DATABASE_COLLATION',

    ];
}
