import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class db {
    @Id
    private String Host;

     @Id
    private String Db;

     @Id
    private String User;

     private String Select_priv;

     private String Insert_priv;

     private String Update_priv;

     private String Delete_priv;

     private String Create_priv;

     private String Drop_priv;

     private String Grant_priv;

     private String References_priv;

     private String Index_priv;

     private String Alter_priv;

     private String Create_tmp_table_priv;

     private String Lock_tables_priv;

     private String Create_view_priv;

     private String Show_view_priv;

     private String Create_routine_priv;

     private String Alter_routine_priv;

     private String Execute_priv;

     private String Event_priv;

     private String Trigger_priv;

     private String Delete_history_priv;

 }