export interface Events_transactions_summary_by_user_by_event_name {
    USER: string;

    EVENT_NAME: string;

    COUNT_STAR: number;

    SUM_TIMER_WAIT: number;

    MIN_TIMER_WAIT: number;

    AVG_TIMER_WAIT: number;

    MAX_TIMER_WAIT: number;

    COUNT_READ_WRITE: number;

    SUM_TIMER_READ_WRITE: number;

    MIN_TIMER_READ_WRITE: number;

    AVG_TIMER_READ_WRITE: number;

    MAX_TIMER_READ_WRITE: number;

    COUNT_READ_ONLY: number;

    SUM_TIMER_READ_ONLY: number;

    MIN_TIMER_READ_ONLY: number;

    AVG_TIMER_READ_ONLY: number;

    MAX_TIMER_READ_ONLY: number;

}