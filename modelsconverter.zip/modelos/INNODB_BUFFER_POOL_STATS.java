import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class INNODB_BUFFER_POOL_STATS {
    private int POOL_ID;

     private long POOL_SIZE;

     private long FREE_BUFFERS;

     private long DATABASE_PAGES;

     private long OLD_DATABASE_PAGES;

     private long MODIFIED_DATABASE_PAGES;

     private long PENDING_DECOMPRESS;

     private long PENDING_READS;

     private long PENDING_FLUSH_LRU;

     private long PENDING_FLUSH_LIST;

     private long PAGES_MADE_YOUNG;

     private long PAGES_NOT_MADE_YOUNG;

     private float PAGES_MADE_YOUNG_RATE;

     private float PAGES_MADE_NOT_YOUNG_RATE;

     private long NUMBER_PAGES_READ;

     private long NUMBER_PAGES_CREATED;

     private long NUMBER_PAGES_WRITTEN;

     private float PAGES_READ_RATE;

     private float PAGES_CREATE_RATE;

     private float PAGES_WRITTEN_RATE;

     private long NUMBER_PAGES_GET;

     private long HIT_RATE;

     private long YOUNG_MAKE_PER_THOUSAND_GETS;

     private long NOT_YOUNG_MAKE_PER_THOUSAND_GETS;

     private long NUMBER_PAGES_READ_AHEAD;

     private long NUMBER_READ_AHEAD_EVICTED;

     private float READ_AHEAD_RATE;

     private float READ_AHEAD_EVICTED_RATE;

     private long LRU_IO_TOTAL;

     private long LRU_IO_CURRENT;

     private long UNCOMPRESS_TOTAL;

     private long UNCOMPRESS_CURRENT;

 }