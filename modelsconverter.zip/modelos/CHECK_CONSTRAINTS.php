
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CHECK_CONSTRAINTS extends Model
{
    protected $table = 'CHECK_CONSTRAINTS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'CONSTRAINT_CATALOG',
        'CONSTRAINT_SCHEMA',
        'TABLE_NAME',
        'CONSTRAINT_NAME',
        'LEVEL',
        'CHECK_CLAUSE',

    ];
}
