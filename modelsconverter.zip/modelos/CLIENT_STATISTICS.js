
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const CLIENT_STATISTICS = Sequelize.define('CLIENT_STATISTICS', {

    CLIENT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TOTAL_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    CONCURRENT_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    CONNECTED_TIME: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    BUSY_TIME: {
        type: DataTypes.DOUBLE,
        allowNull: false,
        
    },

    CPU_TIME: {
        type: DataTypes.DOUBLE,
        allowNull: false,
        
    },

    BYTES_RECEIVED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    BYTES_SENT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    BINLOG_BYTES_WRITTEN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_READ: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_SENT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_DELETED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_INSERTED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_UPDATED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SELECT_COMMANDS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    UPDATE_COMMANDS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    OTHER_COMMANDS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COMMIT_TRANSACTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROLLBACK_TRANSACTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    DENIED_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    LOST_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ACCESS_DENIED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    EMPTY_QUERIES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    TOTAL_SSL_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_STATEMENT_TIME_EXCEEDED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = CLIENT_STATISTICS;