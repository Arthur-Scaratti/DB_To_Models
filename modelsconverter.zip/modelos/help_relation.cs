
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Help_relation
    {

        [Required]
        [Key]
        public int Help_topic_id { get; set; }
        /// help_topic_id
        [Required]
        [Key]
        public int Help_keyword_id { get; set; }
        /// help_keyword_id
    }
}
