
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FILES extends Model
{
    protected $table = 'FILES';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'FILE_ID',
        'FILE_NAME',
        'FILE_TYPE',
        'TABLESPACE_NAME',
        'TABLE_CATALOG',
        'TABLE_SCHEMA',
        'TABLE_NAME',
        'LOGFILE_GROUP_NAME',
        'LOGFILE_GROUP_NUMBER',
        'ENGINE',
        'FULLTEXT_KEYS',
        'DELETED_ROWS',
        'UPDATE_COUNT',
        'FREE_EXTENTS',
        'TOTAL_EXTENTS',
        'EXTENT_SIZE',
        'INITIAL_SIZE',
        'MAXIMUM_SIZE',
        'AUTOEXTEND_SIZE',
        'CREATION_TIME',
        'LAST_UPDATE_TIME',
        'LAST_ACCESS_TIME',
        'RECOVER_TIME',
        'TRANSACTION_COUNTER',
        'VERSION',
        'ROW_FORMAT',
        'TABLE_ROWS',
        'AVG_ROW_LENGTH',
        'DATA_LENGTH',
        'MAX_DATA_LENGTH',
        'INDEX_LENGTH',
        'DATA_FREE',
        'CREATE_TIME',
        'UPDATE_TIME',
        'CHECK_TIME',
        'CHECKSUM',
        'STATUS',
        'EXTRA',

    ];
}
