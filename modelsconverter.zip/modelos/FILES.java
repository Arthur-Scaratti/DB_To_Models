import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class FILES {
    private long FILE_ID;

     private String FILE_NAME;

     private String FILE_TYPE;

     private String TABLESPACE_NAME;

     private String TABLE_CATALOG;

     private String TABLE_SCHEMA;

     private String TABLE_NAME;

     private String LOGFILE_GROUP_NAME;

     private long LOGFILE_GROUP_NUMBER;

     private String ENGINE;

     private String FULLTEXT_KEYS;

     private long DELETED_ROWS;

     private long UPDATE_COUNT;

     private long FREE_EXTENTS;

     private long TOTAL_EXTENTS;

     private long EXTENT_SIZE;

     private long INITIAL_SIZE;

     private long MAXIMUM_SIZE;

     private long AUTOEXTEND_SIZE;

     private Date CREATION_TIME;

     private Date LAST_UPDATE_TIME;

     private Date LAST_ACCESS_TIME;

     private long RECOVER_TIME;

     private long TRANSACTION_COUNTER;

     private long VERSION;

     private String ROW_FORMAT;

     private long TABLE_ROWS;

     private long AVG_ROW_LENGTH;

     private long DATA_LENGTH;

     private long MAX_DATA_LENGTH;

     private long INDEX_LENGTH;

     private long DATA_FREE;

     private Date CREATE_TIME;

     private Date UPDATE_TIME;

     private Date CHECK_TIME;

     private long CHECKSUM;

     private String STATUS;

     private String EXTRA;

 }