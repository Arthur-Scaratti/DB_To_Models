
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_waits_current extends Model
{
    protected $table = 'events_waits_current';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'THREAD_ID',
        'EVENT_ID',
        'END_EVENT_ID',
        'EVENT_NAME',
        'SOURCE',
        'TIMER_START',
        'TIMER_END',
        'TIMER_WAIT',
        'SPINS',
        'OBJECT_SCHEMA',
        'OBJECT_NAME',
        'INDEX_NAME',
        'OBJECT_TYPE',
        'OBJECT_INSTANCE_BEGIN',
        'NESTING_EVENT_ID',
        'NESTING_EVENT_TYPE',
        'OPERATION',
        'NUMBER_OF_BYTES',
        'FLAGS',

    ];
}
