import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class ENABLED_ROLES {
    private String ROLE_NAME;

 }