export interface Db {
    Host: string;

    Db: string;

    User: string;

    Select_priv: string;

    Insert_priv: string;

    Update_priv: string;

    Delete_priv: string;

    Create_priv: string;

    Drop_priv: string;

    Grant_priv: string;

    References_priv: string;

    Index_priv: string;

    Alter_priv: string;

    Create_tmp_table_priv: string;

    Lock_tables_priv: string;

    Create_view_priv: string;

    Show_view_priv: string;

    Create_routine_priv: string;

    Alter_routine_priv: string;

    Execute_priv: string;

    Event_priv: string;

    Trigger_priv: string;

    Delete_history_priv: string;

}