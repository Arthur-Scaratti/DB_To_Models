
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Global_status
    {

        [Required]
        [StringLength(64)]
        public string? VARIABLE_NAME { get; set; }
        /// VARIABLE_NAME
        [StringLength(1024)]
        public string? VARIABLE_VALUE { get; set; }
        /// VARIABLE_VALUE
    }
}
