export interface ENABLED_ROLES {
    ROLE_NAME: string;

}