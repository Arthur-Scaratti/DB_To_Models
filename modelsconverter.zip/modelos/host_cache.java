import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class host_cache {
    private String IP;

     private String HOST;

     private String HOST_VALIDATED;

     private long SUM_CONNECT_ERRORS;

     private long COUNT_HOST_BLOCKED_ERRORS;

     private long COUNT_NAMEINFO_TRANSIENT_ERRORS;

     private long COUNT_NAMEINFO_PERMANENT_ERRORS;

     private long COUNT_FORMAT_ERRORS;

     private long COUNT_ADDRINFO_TRANSIENT_ERRORS;

     private long COUNT_ADDRINFO_PERMANENT_ERRORS;

     private long COUNT_FCRDNS_ERRORS;

     private long COUNT_HOST_ACL_ERRORS;

     private long COUNT_NO_AUTH_PLUGIN_ERRORS;

     private long COUNT_AUTH_PLUGIN_ERRORS;

     private long COUNT_HANDSHAKE_ERRORS;

     private long COUNT_PROXY_USER_ERRORS;

     private long COUNT_PROXY_USER_ACL_ERRORS;

     private long COUNT_AUTHENTICATION_ERRORS;

     private long COUNT_SSL_ERRORS;

     private long COUNT_MAX_USER_CONNECTIONS_ERRORS;

     private long COUNT_MAX_USER_CONNECTIONS_PER_HOUR_ERRORS;

     private long COUNT_DEFAULT_DATABASE_ERRORS;

     private long COUNT_INIT_CONNECT_ERRORS;

     private long COUNT_LOCAL_ERRORS;

     private long COUNT_UNKNOWN_ERRORS;

     private String FIRST_SEEN;

     private String LAST_SEEN;

     private String FIRST_ERROR_SEEN;

     private String LAST_ERROR_SEEN;

 }