
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Index_stats = Sequelize.define('index_stats', {

    Db_name: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true,
    },

    Table_name: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true,
    },

    Index_name: {
        type: DataTypes.STRING,
        allowNull: false,
        primaryKey: true,
    },

    Prefix_arity: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    Avg_frequency: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Index_stats;