
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class ENABLED_ROLES
    {

        [StringLength(128)]
        public string? ROLE_NAME { get; set; }
        /// ROLE_NAME
    }
}
