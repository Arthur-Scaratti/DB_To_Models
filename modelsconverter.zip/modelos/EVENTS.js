
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const EVENTS = Sequelize.define('EVENTS', {

    EVENT_CATALOG: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EVENT_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    DEFINER: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TIME_ZONE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EVENT_BODY: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EVENT_DEFINITION: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

    EVENT_TYPE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EXECUTE_AT: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    INTERVAL_VALUE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    INTERVAL_FIELD: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    SQL_MODE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    STARTS: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    ENDS: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    STATUS: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    ON_COMPLETION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    CREATED: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    LAST_ALTERED: {
        type: DataTypes.DATE,
        allowNull: false,
        
    },

    LAST_EXECUTED: {
        type: DataTypes.DATE,
        allowNull: true,
        
    },

    EVENT_COMMENT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    ORIGINATOR: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    CHARACTER_SET_CLIENT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COLLATION_CONNECTION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    DATABASE_COLLATION: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = EVENTS;