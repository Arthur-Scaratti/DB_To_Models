export interface File_instances {
    FILE_NAME: string;

    EVENT_NAME: string;

    OPEN_COUNT: number;

}