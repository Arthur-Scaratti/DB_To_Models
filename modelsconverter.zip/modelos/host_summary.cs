
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_summary
    {

        [StringLength(255)]
        public string? Host { get; set; }
        /// host
    
        public decimal Statements { get; set; }
        /// statements
        [StringLength(12)]
        public string? Statement_latency { get; set; }
        /// statement_latency
        [StringLength(12)]
        public string? Statement_avg_latency { get; set; }
        /// statement_avg_latency
    
        public decimal Table_scans { get; set; }
        /// table_scans
    
        public decimal File_ios { get; set; }
        /// file_ios
        [StringLength(12)]
        public string? File_io_latency { get; set; }
        /// file_io_latency
    
        public decimal Current_connections { get; set; }
        /// current_connections
    
        public decimal Total_connections { get; set; }
        /// total_connections
        [Required]
        public long Unique_users { get; set; }
        /// unique_users
    
        public string? Current_memory { get; set; }
        /// current_memory
    
        public string? Total_memory_allocated { get; set; }
        /// total_memory_allocated
    }
}
