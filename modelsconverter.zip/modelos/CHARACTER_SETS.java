import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class CHARACTER_SETS {
    private String CHARACTER_SET_NAME;

     private String DEFAULT_COLLATE_NAME;

     private String DESCRIPTION;

     private long MAXLEN;

 }