
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ENABLED_ROLES extends Model
{
    protected $table = 'ENABLED_ROLES';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'ROLE_NAME',

    ];
}
