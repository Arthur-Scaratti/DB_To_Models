
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const INNODB_BUFFER_PAGE = Sequelize.define('INNODB_BUFFER_PAGE', {

    POOL_ID: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    BLOCK_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SPACE: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    PAGE_NUMBER: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    PAGE_TYPE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    FLUSH_TYPE: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    FIX_COUNT: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    IS_HASHED: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    NEWEST_MODIFICATION: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    OLDEST_MODIFICATION: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ACCESS_TIME: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    TABLE_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    INDEX_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    NUMBER_RECORDS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    DATA_SIZE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COMPRESSED_SIZE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    PAGE_STATE: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    IO_FIX: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    IS_OLD: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

    FREE_PAGE_CLOCK: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = INNODB_BUFFER_PAGE;