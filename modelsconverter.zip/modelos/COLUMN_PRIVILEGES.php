
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class COLUMN_PRIVILEGES extends Model
{
    protected $table = 'COLUMN_PRIVILEGES';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'GRANTEE',
        'TABLE_CATALOG',
        'TABLE_SCHEMA',
        'TABLE_NAME',
        'COLUMN_NAME',
        'PRIVILEGE_TYPE',
        'IS_GRANTABLE',

    ];
}
