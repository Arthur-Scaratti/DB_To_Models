
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Innodb_buffer_stats_by_schema
    {

    
        public string? Object_schema { get; set; }
        /// object_schema
    
        public string? Allocated { get; set; }
        /// allocated
    
        public string? Data { get; set; }
        /// data
        [Required]
        public long Pages { get; set; }
        /// pages
        [Required]
        public long Pages_hashed { get; set; }
        /// pages_hashed
        [Required]
        public long Pages_old { get; set; }
        /// pages_old
    
        public decimal Rows_cached { get; set; }
        /// rows_cached
    }
}
