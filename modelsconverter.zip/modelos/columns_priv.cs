
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Columns_priv
    {

        [Required]
        [Key]
        public string? Host { get; set; }
        /// Host
        [Required]
        [Key]
        public string? Db { get; set; }
        /// Db
        [Required]
        [Key]
        public string? User { get; set; }
        /// User
        [Required]
        [Key]
        public string? Table_name { get; set; }
        /// Table_name
        [Required]
        [Key]
        public string? Column_name { get; set; }
        /// Column_name
        [Required]
        public string? Timestamp { get; set; }
        /// Timestamp
        [Required]
        public string? Column_priv { get; set; }
        /// Column_priv
    }
}
