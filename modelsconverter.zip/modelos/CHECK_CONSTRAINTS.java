import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class CHECK_CONSTRAINTS {
    private String CONSTRAINT_CATALOG;

     private String CONSTRAINT_SCHEMA;

     private String TABLE_NAME;

     private String CONSTRAINT_NAME;

     private String LEVEL;

     private String CHECK_CLAUSE;

 }