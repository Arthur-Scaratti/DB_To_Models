
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Db extends Model
{
    protected $table = 'db';
   
    protected $primaryKey = ['Host', 'Db', 'User'];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Db',
        'User',
        'Select_priv',
        'Insert_priv',
        'Update_priv',
        'Delete_priv',
        'Create_priv',
        'Drop_priv',
        'Grant_priv',
        'References_priv',
        'Index_priv',
        'Alter_priv',
        'Create_tmp_table_priv',
        'Lock_tables_priv',
        'Create_view_priv',
        'Show_view_priv',
        'Create_routine_priv',
        'Alter_routine_priv',
        'Execute_priv',
        'Event_priv',
        'Trigger_priv',
        'Delete_history_priv',

    ];
}
