
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const File_instances = Sequelize.define('file_instances', {

    FILE_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    OPEN_COUNT: {
        type: DataTypes.INTEGER,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = File_instances;