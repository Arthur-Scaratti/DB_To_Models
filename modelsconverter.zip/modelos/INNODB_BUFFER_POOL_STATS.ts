export interface INNODB_BUFFER_POOL_STATS {
    POOL_ID: number;

    POOL_SIZE: number;

    FREE_BUFFERS: number;

    DATABASE_PAGES: number;

    OLD_DATABASE_PAGES: number;

    MODIFIED_DATABASE_PAGES: number;

    PENDING_DECOMPRESS: number;

    PENDING_READS: number;

    PENDING_FLUSH_LRU: number;

    PENDING_FLUSH_LIST: number;

    PAGES_MADE_YOUNG: number;

    PAGES_NOT_MADE_YOUNG: number;

    PAGES_MADE_YOUNG_RATE: number;

    PAGES_MADE_NOT_YOUNG_RATE: number;

    NUMBER_PAGES_READ: number;

    NUMBER_PAGES_CREATED: number;

    NUMBER_PAGES_WRITTEN: number;

    PAGES_READ_RATE: number;

    PAGES_CREATE_RATE: number;

    PAGES_WRITTEN_RATE: number;

    NUMBER_PAGES_GET: number;

    HIT_RATE: number;

    YOUNG_MAKE_PER_THOUSAND_GETS: number;

    NOT_YOUNG_MAKE_PER_THOUSAND_GETS: number;

    NUMBER_PAGES_READ_AHEAD: number;

    NUMBER_READ_AHEAD_EVICTED: number;

    READ_AHEAD_RATE: number;

    READ_AHEAD_EVICTED_RATE: number;

    LRU_IO_TOTAL: number;

    LRU_IO_CURRENT: number;

    UNCOMPRESS_TOTAL: number;

    UNCOMPRESS_CURRENT: number;

}