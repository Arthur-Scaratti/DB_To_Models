
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Columns_priv extends Model
{
    protected $table = 'columns_priv';
   
    protected $primaryKey = ['Host', 'Db', 'User', 'Table_name', 'Column_name'];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Db',
        'User',
        'Table_name',
        'Column_name',
        'Timestamp',
        'Column_priv',

    ];
}
