
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Capitulos(Base):
    __tablename__ = 'capitulos'

    CAP_NRO = Column(Integer, nullable=False)

    CAP_ID = Column(Integer, primary_key=True, nullable=False)

    NOVEL_ID = Column(Integer, nullable=False)

    TITULO = Column(String)

    CONTEUDO = Column(Text)

    NAME = Column(String)

    LANGUAGE = Column(String, nullable=False)

