
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class File_summary_by_event_name extends Model
{
    protected $table = 'file_summary_by_event_name';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'EVENT_NAME',
        'COUNT_STAR',
        'SUM_TIMER_WAIT',
        'MIN_TIMER_WAIT',
        'AVG_TIMER_WAIT',
        'MAX_TIMER_WAIT',
        'COUNT_READ',
        'SUM_TIMER_READ',
        'MIN_TIMER_READ',
        'AVG_TIMER_READ',
        'MAX_TIMER_READ',
        'SUM_NUMBER_OF_BYTES_READ',
        'COUNT_WRITE',
        'SUM_TIMER_WRITE',
        'MIN_TIMER_WRITE',
        'AVG_TIMER_WRITE',
        'MAX_TIMER_WRITE',
        'SUM_NUMBER_OF_BYTES_WRITE',
        'COUNT_MISC',
        'SUM_TIMER_MISC',
        'MIN_TIMER_MISC',
        'AVG_TIMER_MISC',
        'MAX_TIMER_MISC',

    ];
}
