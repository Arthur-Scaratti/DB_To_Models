
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Help_topic = Sequelize.define('help_topic', {

    Help_topic_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        primaryKey: true,
    },

    Name: {
        type: DataTypes.CHAR,
        allowNull: false,
        
    },

    Help_category_id: {
        type: DataTypes.SMALLINT,
        allowNull: false,
        
    },

    Description: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

    Example: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

    Url: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Help_topic;