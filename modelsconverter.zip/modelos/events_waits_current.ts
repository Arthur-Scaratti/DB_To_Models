export interface Events_waits_current {
    THREAD_ID: number;

    EVENT_ID: number;

    END_EVENT_ID: number;

    EVENT_NAME: string;

    SOURCE: string;

    TIMER_START: number;

    TIMER_END: number;

    TIMER_WAIT: number;

    SPINS: number;

    OBJECT_SCHEMA: string;

    OBJECT_NAME: string;

    INDEX_NAME: string;

    OBJECT_TYPE: string;

    OBJECT_INSTANCE_BEGIN: number;

    NESTING_EVENT_ID: number;

    NESTING_EVENT_TYPE: string;

    OPERATION: string;

    NUMBER_OF_BYTES: number;

    FLAGS: number;

}