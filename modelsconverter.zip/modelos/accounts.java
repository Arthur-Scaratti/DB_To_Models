import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class accounts {
    private String USER;

     private String HOST;

     private long CURRENT_CONNECTIONS;

     private long TOTAL_CONNECTIONS;

 }