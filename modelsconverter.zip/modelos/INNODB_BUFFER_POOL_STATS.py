
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class INNODB_BUFFER_POOL_STATS(Base):
    __tablename__ = 'INNODB_BUFFER_POOL_STATS'

    POOL_ID = Column(Integer, nullable=False)

    POOL_SIZE = Column(BigInteger, nullable=False)

    FREE_BUFFERS = Column(BigInteger, nullable=False)

    DATABASE_PAGES = Column(BigInteger, nullable=False)

    OLD_DATABASE_PAGES = Column(BigInteger, nullable=False)

    MODIFIED_DATABASE_PAGES = Column(BigInteger, nullable=False)

    PENDING_DECOMPRESS = Column(BigInteger, nullable=False)

    PENDING_READS = Column(BigInteger, nullable=False)

    PENDING_FLUSH_LRU = Column(BigInteger, nullable=False)

    PENDING_FLUSH_LIST = Column(BigInteger, nullable=False)

    PAGES_MADE_YOUNG = Column(BigInteger, nullable=False)

    PAGES_NOT_MADE_YOUNG = Column(BigInteger, nullable=False)

    PAGES_MADE_YOUNG_RATE = Column(Float, nullable=False)

    PAGES_MADE_NOT_YOUNG_RATE = Column(Float, nullable=False)

    NUMBER_PAGES_READ = Column(BigInteger, nullable=False)

    NUMBER_PAGES_CREATED = Column(BigInteger, nullable=False)

    NUMBER_PAGES_WRITTEN = Column(BigInteger, nullable=False)

    PAGES_READ_RATE = Column(Float, nullable=False)

    PAGES_CREATE_RATE = Column(Float, nullable=False)

    PAGES_WRITTEN_RATE = Column(Float, nullable=False)

    NUMBER_PAGES_GET = Column(BigInteger, nullable=False)

    HIT_RATE = Column(BigInteger, nullable=False)

    YOUNG_MAKE_PER_THOUSAND_GETS = Column(BigInteger, nullable=False)

    NOT_YOUNG_MAKE_PER_THOUSAND_GETS = Column(BigInteger, nullable=False)

    NUMBER_PAGES_READ_AHEAD = Column(BigInteger, nullable=False)

    NUMBER_READ_AHEAD_EVICTED = Column(BigInteger, nullable=False)

    READ_AHEAD_RATE = Column(Float, nullable=False)

    READ_AHEAD_EVICTED_RATE = Column(Float, nullable=False)

    LRU_IO_TOTAL = Column(BigInteger, nullable=False)

    LRU_IO_CURRENT = Column(BigInteger, nullable=False)

    UNCOMPRESS_TOTAL = Column(BigInteger, nullable=False)

    UNCOMPRESS_CURRENT = Column(BigInteger, nullable=False)

