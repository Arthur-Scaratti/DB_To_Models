
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class General_log
    {

        [Required]
        public string? Event_time { get; set; }
        /// event_time
        [Required]
        public string? User_host { get; set; }
        /// user_host
        [Required]
        public long Thread_id { get; set; }
        /// thread_id
        [Required]
        public int Server_id { get; set; }
        /// server_id
        [Required]
        [StringLength(64)]
        public string? Command_type { get; set; }
        /// command_type
        [Required]
        public string? Argument { get; set; }
        /// argument
    }
}
