export interface Hosts {
    HOST: string;

    CURRENT_CONNECTIONS: number;

    TOTAL_CONNECTIONS: number;

}