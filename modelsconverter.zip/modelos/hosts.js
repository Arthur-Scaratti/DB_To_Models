
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Hosts = Sequelize.define('hosts', {

    HOST: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    CURRENT_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    TOTAL_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Hosts;