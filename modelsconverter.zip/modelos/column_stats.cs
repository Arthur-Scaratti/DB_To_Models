
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Column_stats
    {

        [Required]
        [StringLength(64)]
        [Key]
        public string? Db_name { get; set; }
        /// db_name
        [Required]
        [StringLength(64)]
        [Key]
        public string? Table_name { get; set; }
        /// table_name
        [Required]
        [StringLength(64)]
        [Key]
        public string? Column_name { get; set; }
        /// column_name
    
        public byte[]? Min_value { get; set; }
        /// min_value
    
        public byte[]? Max_value { get; set; }
        /// max_value
    
        public decimal Nulls_ratio { get; set; }
        /// nulls_ratio
    
        public decimal Avg_length { get; set; }
        /// avg_length
    
        public decimal Avg_frequency { get; set; }
        /// avg_frequency
    
        public int Hist_size { get; set; }
        /// hist_size
    
        public string? Hist_type { get; set; }
        /// hist_type
    
        public byte[]? Histogram { get; set; }
        /// histogram
    }
}
