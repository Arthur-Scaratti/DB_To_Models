export interface Events_transactions_history {
    THREAD_ID: number;

    EVENT_ID: number;

    END_EVENT_ID: number;

    EVENT_NAME: string;

    STATE: string;

    TRX_ID: number;

    GTID: string;

    XID_FORMAT_ID: number;

    XID_GTRID: string;

    XID_BQUAL: string;

    XA_STATE: string;

    SOURCE: string;

    TIMER_START: number;

    TIMER_END: number;

    TIMER_WAIT: number;

    ACCESS_MODE: string;

    ISOLATION_LEVEL: string;

    AUTOCOMMIT: string;

    NUMBER_OF_SAVEPOINTS: number;

    NUMBER_OF_ROLLBACK_TO_SAVEPOINT: number;

    NUMBER_OF_RELEASE_SAVEPOINT: number;

    OBJECT_INSTANCE_BEGIN: number;

    NESTING_EVENT_ID: number;

    NESTING_EVENT_TYPE: string;

}