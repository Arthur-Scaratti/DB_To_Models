export interface CLIENT_STATISTICS {
    CLIENT: string;

    TOTAL_CONNECTIONS: number;

    CONCURRENT_CONNECTIONS: number;

    CONNECTED_TIME: number;

    BUSY_TIME: number;

    CPU_TIME: number;

    BYTES_RECEIVED: number;

    BYTES_SENT: number;

    BINLOG_BYTES_WRITTEN: number;

    ROWS_READ: number;

    ROWS_SENT: number;

    ROWS_DELETED: number;

    ROWS_INSERTED: number;

    ROWS_UPDATED: number;

    SELECT_COMMANDS: number;

    UPDATE_COMMANDS: number;

    OTHER_COMMANDS: number;

    COMMIT_TRANSACTIONS: number;

    ROLLBACK_TRANSACTIONS: number;

    DENIED_CONNECTIONS: number;

    LOST_CONNECTIONS: number;

    ACCESS_DENIED: number;

    EMPTY_QUERIES: number;

    TOTAL_SSL_CONNECTIONS: number;

    MAX_STATEMENT_TIME_EXCEEDED: number;

}