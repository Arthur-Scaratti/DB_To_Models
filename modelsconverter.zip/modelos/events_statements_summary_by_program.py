
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Events_statements_summary_by_program(Base):
    __tablename__ = 'events_statements_summary_by_program'

    OBJECT_TYPE = Column(Enum)

    OBJECT_SCHEMA = Column(String, nullable=False)

    OBJECT_NAME = Column(String, nullable=False)

    COUNT_STAR = Column(BigInteger, nullable=False)

    SUM_TIMER_WAIT = Column(BigInteger, nullable=False)

    MIN_TIMER_WAIT = Column(BigInteger, nullable=False)

    AVG_TIMER_WAIT = Column(BigInteger, nullable=False)

    MAX_TIMER_WAIT = Column(BigInteger, nullable=False)

    COUNT_STATEMENTS = Column(BigInteger, nullable=False)

    SUM_STATEMENTS_WAIT = Column(BigInteger, nullable=False)

    MIN_STATEMENTS_WAIT = Column(BigInteger, nullable=False)

    AVG_STATEMENTS_WAIT = Column(BigInteger, nullable=False)

    MAX_STATEMENTS_WAIT = Column(BigInteger, nullable=False)

    SUM_LOCK_TIME = Column(BigInteger, nullable=False)

    SUM_ERRORS = Column(BigInteger, nullable=False)

    SUM_WARNINGS = Column(BigInteger, nullable=False)

    SUM_ROWS_AFFECTED = Column(BigInteger, nullable=False)

    SUM_ROWS_SENT = Column(BigInteger, nullable=False)

    SUM_ROWS_EXAMINED = Column(BigInteger, nullable=False)

    SUM_CREATED_TMP_DISK_TABLES = Column(BigInteger, nullable=False)

    SUM_CREATED_TMP_TABLES = Column(BigInteger, nullable=False)

    SUM_SELECT_FULL_JOIN = Column(BigInteger, nullable=False)

    SUM_SELECT_FULL_RANGE_JOIN = Column(BigInteger, nullable=False)

    SUM_SELECT_RANGE = Column(BigInteger, nullable=False)

    SUM_SELECT_RANGE_CHECK = Column(BigInteger, nullable=False)

    SUM_SELECT_SCAN = Column(BigInteger, nullable=False)

    SUM_SORT_MERGE_PASSES = Column(BigInteger, nullable=False)

    SUM_SORT_RANGE = Column(BigInteger, nullable=False)

    SUM_SORT_ROWS = Column(BigInteger, nullable=False)

    SUM_SORT_SCAN = Column(BigInteger, nullable=False)

    SUM_NO_INDEX_USED = Column(BigInteger, nullable=False)

    SUM_NO_GOOD_INDEX_USED = Column(BigInteger, nullable=False)

