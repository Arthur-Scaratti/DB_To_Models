
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_summary_by_file_io_type
    {

        [StringLength(255)]
        public string? Host { get; set; }
        /// host
        [Required]
        [StringLength(128)]
        public string? Event_name { get; set; }
        /// event_name
        [Required]
        public long Total { get; set; }
        /// total
        [StringLength(12)]
        public string? Total_latency { get; set; }
        /// total_latency
        [StringLength(12)]
        public string? Max_latency { get; set; }
        /// max_latency
    }
}
