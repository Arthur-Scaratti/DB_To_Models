
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CHARACTER_SETS extends Model
{
    protected $table = 'CHARACTER_SETS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'CHARACTER_SET_NAME',
        'DEFAULT_COLLATE_NAME',
        'DESCRIPTION',
        'MAXLEN',

    ];
}
