
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_stages_history_long extends Model
{
    protected $table = 'events_stages_history_long';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'THREAD_ID',
        'EVENT_ID',
        'END_EVENT_ID',
        'EVENT_NAME',
        'SOURCE',
        'TIMER_START',
        'TIMER_END',
        'TIMER_WAIT',
        'WORK_COMPLETED',
        'WORK_ESTIMATED',
        'NESTING_EVENT_ID',
        'NESTING_EVENT_TYPE',

    ];
}
