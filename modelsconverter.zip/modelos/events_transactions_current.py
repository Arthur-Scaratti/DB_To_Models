
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Events_transactions_current(Base):
    __tablename__ = 'events_transactions_current'

    THREAD_ID = Column(BigInteger, nullable=False)

    EVENT_ID = Column(BigInteger, nullable=False)

    END_EVENT_ID = Column(BigInteger)

    EVENT_NAME = Column(String, nullable=False)

    STATE = Column(Enum)

    TRX_ID = Column(BigInteger)

    GTID = Column(String)

    XID_FORMAT_ID = Column(Integer)

    XID_GTRID = Column(String)

    XID_BQUAL = Column(String)

    XA_STATE = Column(String)

    SOURCE = Column(String)

    TIMER_START = Column(BigInteger)

    TIMER_END = Column(BigInteger)

    TIMER_WAIT = Column(BigInteger)

    ACCESS_MODE = Column(Enum)

    ISOLATION_LEVEL = Column(String)

    AUTOCOMMIT = Column(Enum, nullable=False)

    NUMBER_OF_SAVEPOINTS = Column(BigInteger)

    NUMBER_OF_ROLLBACK_TO_SAVEPOINT = Column(BigInteger)

    NUMBER_OF_RELEASE_SAVEPOINT = Column(BigInteger)

    OBJECT_INSTANCE_BEGIN = Column(BigInteger)

    NESTING_EVENT_ID = Column(BigInteger)

    NESTING_EVENT_TYPE = Column(Enum)

