
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_waits_summary_by_user_by_event_name
    {

    
        public string? USER { get; set; }
        /// USER
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [Required]
        public long COUNT_STAR { get; set; }
        /// COUNT_STAR
        [Required]
        public long SUM_TIMER_WAIT { get; set; }
        /// SUM_TIMER_WAIT
        [Required]
        public long MIN_TIMER_WAIT { get; set; }
        /// MIN_TIMER_WAIT
        [Required]
        public long AVG_TIMER_WAIT { get; set; }
        /// AVG_TIMER_WAIT
        [Required]
        public long MAX_TIMER_WAIT { get; set; }
        /// MAX_TIMER_WAIT
    }
}
