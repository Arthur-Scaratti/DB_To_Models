
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const ENABLED_ROLES = Sequelize.define('ENABLED_ROLES', {

    ROLE_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = ENABLED_ROLES;