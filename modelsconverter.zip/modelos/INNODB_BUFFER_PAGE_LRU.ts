export interface INNODB_BUFFER_PAGE_LRU {
    POOL_ID: number;

    LRU_POSITION: number;

    SPACE: number;

    PAGE_NUMBER: number;

    PAGE_TYPE: string;

    FLUSH_TYPE: number;

    FIX_COUNT: number;

    IS_HASHED: number;

    NEWEST_MODIFICATION: number;

    OLDEST_MODIFICATION: number;

    ACCESS_TIME: number;

    TABLE_NAME: string;

    INDEX_NAME: string;

    NUMBER_RECORDS: number;

    DATA_SIZE: number;

    COMPRESSED_SIZE: number;

    COMPRESSED: number;

    IO_FIX: string;

    IS_OLD: number;

    FREE_PAGE_CLOCK: number;

}