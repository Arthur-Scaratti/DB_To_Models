
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Capitulos extends Model
{
    protected $table = 'capitulos';
   
    protected $primaryKey = ['CAP_ID'];

    public $timestamps = false;

    protected $fillable = [
        'CAP_NRO',
        'CAP_ID',
        'NOVEL_ID',
        'TITULO',
        'CONTEUDO',
        'NAME',
        'LANGUAGE',

    ];
}
