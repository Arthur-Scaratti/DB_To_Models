
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_waits_summary_by_instance extends Model
{
    protected $table = 'events_waits_summary_by_instance';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'EVENT_NAME',
        'OBJECT_INSTANCE_BEGIN',
        'COUNT_STAR',
        'SUM_TIMER_WAIT',
        'MIN_TIMER_WAIT',
        'AVG_TIMER_WAIT',
        'MAX_TIMER_WAIT',

    ];
}
