
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Db(Base):
    __tablename__ = 'db'

    Host = Column(String, primary_key=True, nullable=False)

    Db = Column(String, primary_key=True, nullable=False)

    User = Column(String, primary_key=True, nullable=False)

    Select_priv = Column(Enum, nullable=False)

    Insert_priv = Column(Enum, nullable=False)

    Update_priv = Column(Enum, nullable=False)

    Delete_priv = Column(Enum, nullable=False)

    Create_priv = Column(Enum, nullable=False)

    Drop_priv = Column(Enum, nullable=False)

    Grant_priv = Column(Enum, nullable=False)

    References_priv = Column(Enum, nullable=False)

    Index_priv = Column(Enum, nullable=False)

    Alter_priv = Column(Enum, nullable=False)

    Create_tmp_table_priv = Column(Enum, nullable=False)

    Lock_tables_priv = Column(Enum, nullable=False)

    Create_view_priv = Column(Enum, nullable=False)

    Show_view_priv = Column(Enum, nullable=False)

    Create_routine_priv = Column(Enum, nullable=False)

    Alter_routine_priv = Column(Enum, nullable=False)

    Execute_priv = Column(Enum, nullable=False)

    Event_priv = Column(Enum, nullable=False)

    Trigger_priv = Column(Enum, nullable=False)

    Delete_history_priv = Column(Enum, nullable=False)

