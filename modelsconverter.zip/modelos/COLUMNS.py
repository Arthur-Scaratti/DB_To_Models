
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class COLUMNS(Base):
    __tablename__ = 'COLUMNS'

    TABLE_CATALOG = Column(String, nullable=False)

    TABLE_SCHEMA = Column(String, nullable=False)

    TABLE_NAME = Column(String, nullable=False)

    COLUMN_NAME = Column(String, nullable=False)

    ORDINAL_POSITION = Column(BigInteger, nullable=False)

    COLUMN_DEFAULT = Column(Text)

    IS_NULLABLE = Column(String, nullable=False)

    DATA_TYPE = Column(String, nullable=False)

    CHARACTER_MAXIMUM_LENGTH = Column(BigInteger)

    CHARACTER_OCTET_LENGTH = Column(BigInteger)

    NUMERIC_PRECISION = Column(BigInteger)

    NUMERIC_SCALE = Column(BigInteger)

    DATETIME_PRECISION = Column(BigInteger)

    CHARACTER_SET_NAME = Column(String)

    COLLATION_NAME = Column(String)

    COLUMN_TYPE = Column(Text, nullable=False)

    COLUMN_KEY = Column(String, nullable=False)

    EXTRA = Column(String, nullable=False)

    PRIVILEGES = Column(String, nullable=False)

    COLUMN_COMMENT = Column(String, nullable=False)

    IS_GENERATED = Column(String, nullable=False)

    GENERATION_EXPRESSION = Column(Text)

