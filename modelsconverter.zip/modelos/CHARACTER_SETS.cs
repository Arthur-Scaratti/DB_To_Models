
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class CHARACTER_SETS
    {

        [Required]
        [StringLength(32)]
        public string? CHARACTER_SET_NAME { get; set; }
        /// CHARACTER_SET_NAME
        [Required]
        [StringLength(64)]
        public string? DEFAULT_COLLATE_NAME { get; set; }
        /// DEFAULT_COLLATE_NAME
        [Required]
        [StringLength(60)]
        public string? DESCRIPTION { get; set; }
        /// DESCRIPTION
        [Required]
        public long MAXLEN { get; set; }
        /// MAXLEN
    }
}
