
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Event(Base):
    __tablename__ = 'event'

    Db = Column(String, primary_key=True, nullable=False)

    Name = Column(String, primary_key=True, nullable=False)

    Body = Column(LargeBinary, nullable=False)

    Definer = Column(String, nullable=False)

    Execute_at = Column(DateTime)

    Interval_value = Column(Integer)

    Interval_field = Column(Enum)

    Created = Column(DateTime, nullable=False)

    Modified = Column(DateTime, nullable=False)

    Last_executed = Column(DateTime)

    Starts = Column(DateTime)

    Ends = Column(DateTime)

    Status = Column(Enum, nullable=False)

    On_completion = Column(Enum, nullable=False)

    Sql_mode = Column(String, nullable=False)

    Comment = Column(String, nullable=False)

    Originator = Column(Integer, nullable=False)

    Time_zone = Column(String, nullable=False)

    Character_set_client = Column(String)

    Collation_connection = Column(String)

    Db_collation = Column(String)

    Body_utf8 = Column(LargeBinary)

