
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Events_statements_history_long extends Model
{
    protected $table = 'events_statements_history_long';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'THREAD_ID',
        'EVENT_ID',
        'END_EVENT_ID',
        'EVENT_NAME',
        'SOURCE',
        'TIMER_START',
        'TIMER_END',
        'TIMER_WAIT',
        'LOCK_TIME',
        'SQL_TEXT',
        'DIGEST',
        'DIGEST_TEXT',
        'CURRENT_SCHEMA',
        'OBJECT_TYPE',
        'OBJECT_SCHEMA',
        'OBJECT_NAME',
        'OBJECT_INSTANCE_BEGIN',
        'MYSQL_ERRNO',
        'RETURNED_SQLSTATE',
        'MESSAGE_TEXT',
        'ERRORS',
        'WARNINGS',
        'ROWS_AFFECTED',
        'ROWS_SENT',
        'ROWS_EXAMINED',
        'CREATED_TMP_DISK_TABLES',
        'CREATED_TMP_TABLES',
        'SELECT_FULL_JOIN',
        'SELECT_FULL_RANGE_JOIN',
        'SELECT_RANGE',
        'SELECT_RANGE_CHECK',
        'SELECT_SCAN',
        'SORT_MERGE_PASSES',
        'SORT_RANGE',
        'SORT_ROWS',
        'SORT_SCAN',
        'NO_INDEX_USED',
        'NO_GOOD_INDEX_USED',
        'NESTING_EVENT_ID',
        'NESTING_EVENT_TYPE',
        'NESTING_EVENT_LEVEL',

    ];
}
