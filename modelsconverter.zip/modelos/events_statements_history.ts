export interface Events_statements_history {
    THREAD_ID: number;

    EVENT_ID: number;

    END_EVENT_ID: number;

    EVENT_NAME: string;

    SOURCE: string;

    TIMER_START: number;

    TIMER_END: number;

    TIMER_WAIT: number;

    LOCK_TIME: number;

    SQL_TEXT: string;

    DIGEST: string;

    DIGEST_TEXT: string;

    CURRENT_SCHEMA: string;

    OBJECT_TYPE: string;

    OBJECT_SCHEMA: string;

    OBJECT_NAME: string;

    OBJECT_INSTANCE_BEGIN: number;

    MYSQL_ERRNO: number;

    RETURNED_SQLSTATE: string;

    MESSAGE_TEXT: string;

    ERRORS: number;

    WARNINGS: number;

    ROWS_AFFECTED: number;

    ROWS_SENT: number;

    ROWS_EXAMINED: number;

    CREATED_TMP_DISK_TABLES: number;

    CREATED_TMP_TABLES: number;

    SELECT_FULL_JOIN: number;

    SELECT_FULL_RANGE_JOIN: number;

    SELECT_RANGE: number;

    SELECT_RANGE_CHECK: number;

    SELECT_SCAN: number;

    SORT_MERGE_PASSES: number;

    SORT_RANGE: number;

    SORT_ROWS: number;

    SORT_SCAN: number;

    NO_INDEX_USED: number;

    NO_GOOD_INDEX_USED: number;

    NESTING_EVENT_ID: number;

    NESTING_EVENT_TYPE: string;

    NESTING_EVENT_LEVEL: number;

}