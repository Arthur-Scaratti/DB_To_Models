
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class APPLICABLE_ROLES extends Model
{
    protected $table = 'APPLICABLE_ROLES';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'GRANTEE',
        'ROLE_NAME',
        'IS_GRANTABLE',
        'IS_DEFAULT',

    ];
}
