
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ENGINES extends Model
{
    protected $table = 'ENGINES';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'ENGINE',
        'SUPPORT',
        'COMMENT',
        'TRANSACTIONS',
        'XA',
        'SAVEPOINTS',

    ];
}
