
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Hosts extends Model
{
    protected $table = 'hosts';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'HOST',
        'CURRENT_CONNECTIONS',
        'TOTAL_CONNECTIONS',

    ];
}
