export interface INNODB_BUFFER_PAGE {
    POOL_ID: number;

    BLOCK_ID: number;

    SPACE: number;

    PAGE_NUMBER: number;

    PAGE_TYPE: string;

    FLUSH_TYPE: number;

    FIX_COUNT: number;

    IS_HASHED: number;

    NEWEST_MODIFICATION: number;

    OLDEST_MODIFICATION: number;

    ACCESS_TIME: number;

    TABLE_NAME: string;

    INDEX_NAME: string;

    NUMBER_RECORDS: number;

    DATA_SIZE: number;

    COMPRESSED_SIZE: number;

    PAGE_STATE: string;

    IO_FIX: string;

    IS_OLD: number;

    FREE_PAGE_CLOCK: number;

}