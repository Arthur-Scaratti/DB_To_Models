
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Events_transactions_history = Sequelize.define('events_transactions_history', {

    THREAD_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    END_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    STATE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    TRX_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    GTID: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    XID_FORMAT_ID: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    XID_GTRID: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    XID_BQUAL: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    XA_STATE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    SOURCE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    TIMER_START: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_END: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    ACCESS_MODE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    ISOLATION_LEVEL: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    AUTOCOMMIT: {
        type: DataTypes.ENUM,
        allowNull: false,
        
    },

    NUMBER_OF_SAVEPOINTS: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NUMBER_OF_ROLLBACK_TO_SAVEPOINT: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NUMBER_OF_RELEASE_SAVEPOINT: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    OBJECT_INSTANCE_BEGIN: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NESTING_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NESTING_EVENT_TYPE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Events_transactions_history;