import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class help_category {
    @Id
    private short Help_category_id;

     private String Name;

     private short Parent_category_id;

     private String Url;

 }