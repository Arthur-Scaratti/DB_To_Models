
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Host_summary_by_statement_type extends Model
{
    protected $table = 'host_summary_by_statement_type';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Statement',
        'Total',
        'Total_latency',
        'Max_latency',
        'Lock_latency',
        'Rows_sent',
        'Rows_examined',
        'Rows_affected',
        'Full_scans',

    ];
}
