<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Global_priv extends Model
{
    protected $table = 'global_priv';
   
    protected $primaryKey = ['Host', 'User'];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'User',
        'Priv',

    ];
}
