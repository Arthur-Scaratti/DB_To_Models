export interface ENGINES {
    ENGINE: string;

    SUPPORT: string;

    COMMENT: string;

    TRANSACTIONS: string;

    XA: string;

    SAVEPOINTS: string;

}