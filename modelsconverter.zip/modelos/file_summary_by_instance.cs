
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class File_summary_by_instance
    {

        [Required]
        [StringLength(512)]
        public string? FILE_NAME { get; set; }
        /// FILE_NAME
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [Required]
        public long OBJECT_INSTANCE_BEGIN { get; set; }
        /// OBJECT_INSTANCE_BEGIN
        [Required]
        public long COUNT_STAR { get; set; }
        /// COUNT_STAR
        [Required]
        public long SUM_TIMER_WAIT { get; set; }
        /// SUM_TIMER_WAIT
        [Required]
        public long MIN_TIMER_WAIT { get; set; }
        /// MIN_TIMER_WAIT
        [Required]
        public long AVG_TIMER_WAIT { get; set; }
        /// AVG_TIMER_WAIT
        [Required]
        public long MAX_TIMER_WAIT { get; set; }
        /// MAX_TIMER_WAIT
        [Required]
        public long COUNT_READ { get; set; }
        /// COUNT_READ
        [Required]
        public long SUM_TIMER_READ { get; set; }
        /// SUM_TIMER_READ
        [Required]
        public long MIN_TIMER_READ { get; set; }
        /// MIN_TIMER_READ
        [Required]
        public long AVG_TIMER_READ { get; set; }
        /// AVG_TIMER_READ
        [Required]
        public long MAX_TIMER_READ { get; set; }
        /// MAX_TIMER_READ
        [Required]
        public long SUM_NUMBER_OF_BYTES_READ { get; set; }
        /// SUM_NUMBER_OF_BYTES_READ
        [Required]
        public long COUNT_WRITE { get; set; }
        /// COUNT_WRITE
        [Required]
        public long SUM_TIMER_WRITE { get; set; }
        /// SUM_TIMER_WRITE
        [Required]
        public long MIN_TIMER_WRITE { get; set; }
        /// MIN_TIMER_WRITE
        [Required]
        public long AVG_TIMER_WRITE { get; set; }
        /// AVG_TIMER_WRITE
        [Required]
        public long MAX_TIMER_WRITE { get; set; }
        /// MAX_TIMER_WRITE
        [Required]
        public long SUM_NUMBER_OF_BYTES_WRITE { get; set; }
        /// SUM_NUMBER_OF_BYTES_WRITE
        [Required]
        public long COUNT_MISC { get; set; }
        /// COUNT_MISC
        [Required]
        public long SUM_TIMER_MISC { get; set; }
        /// SUM_TIMER_MISC
        [Required]
        public long MIN_TIMER_MISC { get; set; }
        /// MIN_TIMER_MISC
        [Required]
        public long AVG_TIMER_MISC { get; set; }
        /// AVG_TIMER_MISC
        [Required]
        public long MAX_TIMER_MISC { get; set; }
        /// MAX_TIMER_MISC
    }
}
