import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class file_summary_by_event_name {
    private String EVENT_NAME;

     private long COUNT_STAR;

     private long SUM_TIMER_WAIT;

     private long MIN_TIMER_WAIT;

     private long AVG_TIMER_WAIT;

     private long MAX_TIMER_WAIT;

     private long COUNT_READ;

     private long SUM_TIMER_READ;

     private long MIN_TIMER_READ;

     private long AVG_TIMER_READ;

     private long MAX_TIMER_READ;

     private long SUM_NUMBER_OF_BYTES_READ;

     private long COUNT_WRITE;

     private long SUM_TIMER_WRITE;

     private long MIN_TIMER_WRITE;

     private long AVG_TIMER_WRITE;

     private long MAX_TIMER_WRITE;

     private long SUM_NUMBER_OF_BYTES_WRITE;

     private long COUNT_MISC;

     private long SUM_TIMER_MISC;

     private long MIN_TIMER_MISC;

     private long AVG_TIMER_MISC;

     private long MAX_TIMER_MISC;

 }