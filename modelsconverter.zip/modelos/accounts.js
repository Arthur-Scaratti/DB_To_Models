
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Accounts = Sequelize.define('accounts', {

    USER: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    HOST: {
        type: DataTypes.CHAR,
        allowNull: true,
        
    },

    CURRENT_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    TOTAL_CONNECTIONS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Accounts;