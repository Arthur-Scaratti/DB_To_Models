
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Gtid_slave_pos(Base):
    __tablename__ = 'gtid_slave_pos'

    Domain_id = Column(Integer, primary_key=True, nullable=False)

    Sub_id = Column(BigInteger, primary_key=True, nullable=False)

    Server_id = Column(Integer, nullable=False)

    Seq_no = Column(BigInteger, nullable=False)

