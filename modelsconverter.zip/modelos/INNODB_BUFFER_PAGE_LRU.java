import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class INNODB_BUFFER_PAGE_LRU {
    private int POOL_ID;

     private long LRU_POSITION;

     private int SPACE;

     private int PAGE_NUMBER;

     private String PAGE_TYPE;

     private int FLUSH_TYPE;

     private int FIX_COUNT;

     private int IS_HASHED;

     private long NEWEST_MODIFICATION;

     private long OLDEST_MODIFICATION;

     private long ACCESS_TIME;

     private String TABLE_NAME;

     private String INDEX_NAME;

     private long NUMBER_RECORDS;

     private long DATA_SIZE;

     private long COMPRESSED_SIZE;

     private int COMPRESSED;

     private String IO_FIX;

     private int IS_OLD;

     private long FREE_PAGE_CLOCK;

 }