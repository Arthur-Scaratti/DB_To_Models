
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class APPLICABLE_ROLES(Base):
    __tablename__ = 'APPLICABLE_ROLES'

    GRANTEE = Column(String, nullable=False)

    ROLE_NAME = Column(String, nullable=False)

    IS_GRANTABLE = Column(String, nullable=False)

    IS_DEFAULT = Column(String)

