
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CLIENT_STATISTICS extends Model
{
    protected $table = 'CLIENT_STATISTICS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'CLIENT',
        'TOTAL_CONNECTIONS',
        'CONCURRENT_CONNECTIONS',
        'CONNECTED_TIME',
        'BUSY_TIME',
        'CPU_TIME',
        'BYTES_RECEIVED',
        'BYTES_SENT',
        'BINLOG_BYTES_WRITTEN',
        'ROWS_READ',
        'ROWS_SENT',
        'ROWS_DELETED',
        'ROWS_INSERTED',
        'ROWS_UPDATED',
        'SELECT_COMMANDS',
        'UPDATE_COMMANDS',
        'OTHER_COMMANDS',
        'COMMIT_TRANSACTIONS',
        'ROLLBACK_TRANSACTIONS',
        'DENIED_CONNECTIONS',
        'LOST_CONNECTIONS',
        'ACCESS_DENIED',
        'EMPTY_QUERIES',
        'TOTAL_SSL_CONNECTIONS',
        'MAX_STATEMENT_TIME_EXCEEDED',

    ];
}
