import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class help_relation {
    @Id
    private int Help_topic_id;

     @Id
    private int Help_keyword_id;

 }