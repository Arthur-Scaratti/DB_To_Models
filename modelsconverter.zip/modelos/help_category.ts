export interface Help_category {
    Help_category_id: number;

    Name: string;

    Parent_category_id: number;

    Url: string;

}