
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class INDEX_STATISTICS extends Model
{
    protected $table = 'INDEX_STATISTICS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'TABLE_SCHEMA',
        'TABLE_NAME',
        'INDEX_NAME',
        'ROWS_READ',

    ];
}
