
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Host_summary_by_stages
    {

        [StringLength(255)]
        public string? Host { get; set; }
        /// host
        [Required]
        [StringLength(128)]
        public string? Event_name { get; set; }
        /// event_name
        [Required]
        public long Total { get; set; }
        /// total
        [StringLength(12)]
        public string? Total_latency { get; set; }
        /// total_latency
        [StringLength(12)]
        public string? Avg_latency { get; set; }
        /// avg_latency
    }
}
