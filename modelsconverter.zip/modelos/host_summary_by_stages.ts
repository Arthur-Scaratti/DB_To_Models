export interface Host_summary_by_stages {
    Host: string;

    Event_name: string;

    Total: number;

    Total_latency: string;

    Avg_latency: string;

}