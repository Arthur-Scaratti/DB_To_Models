
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Events_stages_history(Base):
    __tablename__ = 'events_stages_history'

    THREAD_ID = Column(BigInteger, nullable=False)

    EVENT_ID = Column(BigInteger, nullable=False)

    END_EVENT_ID = Column(BigInteger)

    EVENT_NAME = Column(String, nullable=False)

    SOURCE = Column(String)

    TIMER_START = Column(BigInteger)

    TIMER_END = Column(BigInteger)

    TIMER_WAIT = Column(BigInteger)

    WORK_COMPLETED = Column(BigInteger)

    WORK_ESTIMATED = Column(BigInteger)

    NESTING_EVENT_ID = Column(BigInteger)

    NESTING_EVENT_TYPE = Column(Enum)

