import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class host_summary_by_statement_type {
    private String Host;

     private String Statement;

     private long Total;

     private String Total_latency;

     private String Max_latency;

     private String Lock_latency;

     private long Rows_sent;

     private long Rows_examined;

     private long Rows_affected;

     private long Full_scans;

 }