import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class events_statements_history {
    private long THREAD_ID;

     private long EVENT_ID;

     private long END_EVENT_ID;

     private String EVENT_NAME;

     private String SOURCE;

     private long TIMER_START;

     private long TIMER_END;

     private long TIMER_WAIT;

     private long LOCK_TIME;

     private String SQL_TEXT;

     private String DIGEST;

     private String DIGEST_TEXT;

     private String CURRENT_SCHEMA;

     private String OBJECT_TYPE;

     private String OBJECT_SCHEMA;

     private String OBJECT_NAME;

     private long OBJECT_INSTANCE_BEGIN;

     private int MYSQL_ERRNO;

     private String RETURNED_SQLSTATE;

     private String MESSAGE_TEXT;

     private long ERRORS;

     private long WARNINGS;

     private long ROWS_AFFECTED;

     private long ROWS_SENT;

     private long ROWS_EXAMINED;

     private long CREATED_TMP_DISK_TABLES;

     private long CREATED_TMP_TABLES;

     private long SELECT_FULL_JOIN;

     private long SELECT_FULL_RANGE_JOIN;

     private long SELECT_RANGE;

     private long SELECT_RANGE_CHECK;

     private long SELECT_SCAN;

     private long SORT_MERGE_PASSES;

     private long SORT_RANGE;

     private long SORT_ROWS;

     private long SORT_SCAN;

     private long NO_INDEX_USED;

     private long NO_GOOD_INDEX_USED;

     private long NESTING_EVENT_ID;

     private String NESTING_EVENT_TYPE;

     private int NESTING_EVENT_LEVEL;

 }