
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class File_instances
    {

        [Required]
        [StringLength(512)]
        public string? FILE_NAME { get; set; }
        /// FILE_NAME
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [Required]
        public int OPEN_COUNT { get; set; }
        /// OPEN_COUNT
    }
}
