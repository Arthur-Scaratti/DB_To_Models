
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class APPLICABLE_ROLES
    {

        [Required]
        [StringLength(385)]
        public string? GRANTEE { get; set; }
        /// GRANTEE
        [Required]
        [StringLength(128)]
        public string? ROLE_NAME { get; set; }
        /// ROLE_NAME
        [Required]
        [StringLength(3)]
        public string? IS_GRANTABLE { get; set; }
        /// IS_GRANTABLE
        [StringLength(3)]
        public string? IS_DEFAULT { get; set; }
        /// IS_DEFAULT
    }
}
