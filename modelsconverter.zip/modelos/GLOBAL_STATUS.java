import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class global_status {
    private String VARIABLE_NAME;

     private String VARIABLE_VALUE;

 }