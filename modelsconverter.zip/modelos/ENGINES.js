
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const ENGINES = Sequelize.define('ENGINES', {

    ENGINE: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    SUPPORT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COMMENT: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    TRANSACTIONS: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    XA: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    SAVEPOINTS: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = ENGINES;