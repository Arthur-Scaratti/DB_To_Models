import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class host_summary_by_file_io_type {
    private String Host;

     private String Event_name;

     private long Total;

     private String Total_latency;

     private String Max_latency;

 }