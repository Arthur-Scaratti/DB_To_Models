
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ALL_PLUGINS extends Model
{
    protected $table = 'ALL_PLUGINS';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'PLUGIN_NAME',
        'PLUGIN_VERSION',
        'PLUGIN_STATUS',
        'PLUGIN_TYPE',
        'PLUGIN_TYPE_VERSION',
        'PLUGIN_LIBRARY',
        'PLUGIN_LIBRARY_VERSION',
        'PLUGIN_AUTHOR',
        'PLUGIN_DESCRIPTION',
        'PLUGIN_LICENSE',
        'LOAD_OPTION',
        'PLUGIN_MATURITY',
        'PLUGIN_AUTH_VERSION',

    ];
}
