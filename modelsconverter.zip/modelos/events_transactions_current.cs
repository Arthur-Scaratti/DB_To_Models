
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Events_transactions_current
    {

        [Required]
        public long THREAD_ID { get; set; }
        /// THREAD_ID
        [Required]
        public long EVENT_ID { get; set; }
        /// EVENT_ID
    
        public long END_EVENT_ID { get; set; }
        /// END_EVENT_ID
        [Required]
        [StringLength(128)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
    
        public string? STATE { get; set; }
        /// STATE
    
        public long TRX_ID { get; set; }
        /// TRX_ID
        [StringLength(64)]
        public string? GTID { get; set; }
        /// GTID
    
        public int XID_FORMAT_ID { get; set; }
        /// XID_FORMAT_ID
        [StringLength(130)]
        public string? XID_GTRID { get; set; }
        /// XID_GTRID
        [StringLength(130)]
        public string? XID_BQUAL { get; set; }
        /// XID_BQUAL
        [StringLength(64)]
        public string? XA_STATE { get; set; }
        /// XA_STATE
        [StringLength(64)]
        public string? SOURCE { get; set; }
        /// SOURCE
    
        public long TIMER_START { get; set; }
        /// TIMER_START
    
        public long TIMER_END { get; set; }
        /// TIMER_END
    
        public long TIMER_WAIT { get; set; }
        /// TIMER_WAIT
    
        public string? ACCESS_MODE { get; set; }
        /// ACCESS_MODE
        [StringLength(64)]
        public string? ISOLATION_LEVEL { get; set; }
        /// ISOLATION_LEVEL
        [Required]
        public string? AUTOCOMMIT { get; set; }
        /// AUTOCOMMIT
    
        public long NUMBER_OF_SAVEPOINTS { get; set; }
        /// NUMBER_OF_SAVEPOINTS
    
        public long NUMBER_OF_ROLLBACK_TO_SAVEPOINT { get; set; }
        /// NUMBER_OF_ROLLBACK_TO_SAVEPOINT
    
        public long NUMBER_OF_RELEASE_SAVEPOINT { get; set; }
        /// NUMBER_OF_RELEASE_SAVEPOINT
    
        public long OBJECT_INSTANCE_BEGIN { get; set; }
        /// OBJECT_INSTANCE_BEGIN
    
        public long NESTING_EVENT_ID { get; set; }
        /// NESTING_EVENT_ID
    
        public string? NESTING_EVENT_TYPE { get; set; }
        /// NESTING_EVENT_TYPE
    }
}
