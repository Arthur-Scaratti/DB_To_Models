
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Help_category = Sequelize.define('help_category', {

    Help_category_id: {
        type: DataTypes.SMALLINT,
        allowNull: false,
        primaryKey: true,
    },

    Name: {
        type: DataTypes.CHAR,
        allowNull: false,
        
    },

    Parent_category_id: {
        type: DataTypes.SMALLINT,
        allowNull: true,
        
    },

    Url: {
        type: DataTypes.TEXT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Help_category;