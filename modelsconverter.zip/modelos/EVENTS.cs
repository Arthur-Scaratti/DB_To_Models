
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class EVENTS
    {

        [Required]
        [StringLength(64)]
        public string? EVENT_CATALOG { get; set; }
        /// EVENT_CATALOG
        [Required]
        [StringLength(64)]
        public string? EVENT_SCHEMA { get; set; }
        /// EVENT_SCHEMA
        [Required]
        [StringLength(64)]
        public string? EVENT_NAME { get; set; }
        /// EVENT_NAME
        [Required]
        [StringLength(384)]
        public string? DEFINER { get; set; }
        /// DEFINER
        [Required]
        [StringLength(64)]
        public string? TIME_ZONE { get; set; }
        /// TIME_ZONE
        [Required]
        [StringLength(8)]
        public string? EVENT_BODY { get; set; }
        /// EVENT_BODY
        [Required]
        public string? EVENT_DEFINITION { get; set; }
        /// EVENT_DEFINITION
        [Required]
        [StringLength(9)]
        public string? EVENT_TYPE { get; set; }
        /// EVENT_TYPE
    
        public DateTime? EXECUTE_AT { get; set; }
        /// EXECUTE_AT
        [StringLength(256)]
        public string? INTERVAL_VALUE { get; set; }
        /// INTERVAL_VALUE
        [StringLength(18)]
        public string? INTERVAL_FIELD { get; set; }
        /// INTERVAL_FIELD
        [Required]
        [StringLength(8192)]
        public string? SQL_MODE { get; set; }
        /// SQL_MODE
    
        public DateTime? STARTS { get; set; }
        /// STARTS
    
        public DateTime? ENDS { get; set; }
        /// ENDS
        [Required]
        [StringLength(18)]
        public string? STATUS { get; set; }
        /// STATUS
        [Required]
        [StringLength(12)]
        public string? ON_COMPLETION { get; set; }
        /// ON_COMPLETION
        [Required]
        public DateTime? CREATED { get; set; }
        /// CREATED
        [Required]
        public DateTime? LAST_ALTERED { get; set; }
        /// LAST_ALTERED
    
        public DateTime? LAST_EXECUTED { get; set; }
        /// LAST_EXECUTED
        [Required]
        [StringLength(64)]
        public string? EVENT_COMMENT { get; set; }
        /// EVENT_COMMENT
        [Required]
        public long ORIGINATOR { get; set; }
        /// ORIGINATOR
        [Required]
        [StringLength(32)]
        public string? CHARACTER_SET_CLIENT { get; set; }
        /// CHARACTER_SET_CLIENT
        [Required]
        [StringLength(64)]
        public string? COLLATION_CONNECTION { get; set; }
        /// COLLATION_CONNECTION
        [Required]
        [StringLength(64)]
        public string? DATABASE_COLLATION { get; set; }
        /// DATABASE_COLLATION
    }
}
