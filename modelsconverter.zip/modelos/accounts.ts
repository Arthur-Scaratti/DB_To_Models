export interface Accounts {
    USER: string;

    HOST: string;

    CURRENT_CONNECTIONS: number;

    TOTAL_CONNECTIONS: number;

}