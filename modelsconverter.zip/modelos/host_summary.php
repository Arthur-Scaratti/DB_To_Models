
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Host_summary extends Model
{
    protected $table = 'host_summary';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Statements',
        'Statement_latency',
        'Statement_avg_latency',
        'Table_scans',
        'File_ios',
        'File_io_latency',
        'Current_connections',
        'Total_connections',
        'Unique_users',
        'Current_memory',
        'Total_memory_allocated',

    ];
}
