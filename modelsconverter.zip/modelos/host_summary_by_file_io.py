
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Host_summary_by_file_io(Base):
    __tablename__ = 'host_summary_by_file_io'

    Host = Column(String)

    Ios = Column(Numeric)

    Io_latency = Column(String)

