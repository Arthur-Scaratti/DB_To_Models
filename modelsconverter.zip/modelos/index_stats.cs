
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Index_stats
    {

        [Required]
        [StringLength(64)]
        [Key]
        public string? Db_name { get; set; }
        /// db_name
        [Required]
        [StringLength(64)]
        [Key]
        public string? Table_name { get; set; }
        /// table_name
        [Required]
        [StringLength(64)]
        [Key]
        public string? Index_name { get; set; }
        /// index_name
        [Required]
        [Key]
        public int Prefix_arity { get; set; }
        /// prefix_arity
    
        public decimal Avg_frequency { get; set; }
        /// avg_frequency
    }
}
