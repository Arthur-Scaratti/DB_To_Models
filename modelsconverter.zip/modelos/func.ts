export interface Func {
    Name: string;

    Ret: number;

    Dl: string;

    Type: string;

}