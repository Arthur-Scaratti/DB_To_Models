import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class hosts {
    private String HOST;

     private long CURRENT_CONNECTIONS;

     private long TOTAL_CONNECTIONS;

 }