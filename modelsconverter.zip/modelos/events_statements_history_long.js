
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Events_statements_history_long = Sequelize.define('events_statements_history_long', {

    THREAD_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    END_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    EVENT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    SOURCE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    TIMER_START: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_END: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    LOCK_TIME: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SQL_TEXT: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

    DIGEST: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    DIGEST_TEXT: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

    CURRENT_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_TYPE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_NAME: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    OBJECT_INSTANCE_BEGIN: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    MYSQL_ERRNO: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

    RETURNED_SQLSTATE: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    MESSAGE_TEXT: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    WARNINGS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_AFFECTED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_SENT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    ROWS_EXAMINED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    CREATED_TMP_DISK_TABLES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    CREATED_TMP_TABLES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SELECT_FULL_JOIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SELECT_FULL_RANGE_JOIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SELECT_RANGE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SELECT_RANGE_CHECK: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SELECT_SCAN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SORT_MERGE_PASSES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SORT_RANGE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SORT_ROWS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SORT_SCAN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    NO_INDEX_USED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    NO_GOOD_INDEX_USED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    NESTING_EVENT_ID: {
        type: DataTypes.BIGINT,
        allowNull: true,
        
    },

    NESTING_EVENT_TYPE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    NESTING_EVENT_LEVEL: {
        type: DataTypes.INTEGER,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Events_statements_history_long;