
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Host_summary = Sequelize.define('host_summary', {

    Host: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Statements: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Statement_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Statement_avg_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Table_scans: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    File_ios: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    File_io_latency: {
        type: DataTypes.STRING,
        allowNull: true,
        
    },

    Current_connections: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Total_connections: {
        type: DataTypes.DECIMAL,
        allowNull: true,
        
    },

    Unique_users: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    Current_memory: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

    Total_memory_allocated: {
        type: DataTypes.TEXT,
        allowNull: true,
        
    },

}, {
    timestamps: false,

});

module.exports = Host_summary;