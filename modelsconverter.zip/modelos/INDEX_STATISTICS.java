import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class INDEX_STATISTICS {
    private String TABLE_SCHEMA;

     private String TABLE_NAME;

     private String INDEX_NAME;

     private long ROWS_READ;

 }