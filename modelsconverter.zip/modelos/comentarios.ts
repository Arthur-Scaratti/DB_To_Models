export interface Comentarios {
    COMMENT_ID: number;

    CAP_ID: number;

    NOVEL_ID: number;

    CAP_NRO: number;

    CONTENT: string;

    SENDER: number;

    RECIEVER: number;

    LANGUAGE: string;

}