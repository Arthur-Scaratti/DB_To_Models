
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Host_summary_by_stages extends Model
{
    protected $table = 'host_summary_by_stages';
   
    protected $primaryKey = [];

    public $timestamps = false;

    protected $fillable = [
        'Host',
        'Event_name',
        'Total',
        'Total_latency',
        'Avg_latency',

    ];
}
