
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Help_category
    {

        [Required]
        [Key]
        public short Help_category_id { get; set; }
        /// help_category_id
        [Required]
        public string? Name { get; set; }
        /// name
    
        public short Parent_category_id { get; set; }
        /// parent_category_id
        [Required]
        public string? Url { get; set; }
        /// url
    }
}
