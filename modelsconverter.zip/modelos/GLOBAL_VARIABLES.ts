export interface GLOBAL_VARIABLES {
    VARIABLE_NAME: string;

    VARIABLE_VALUE: string;

}