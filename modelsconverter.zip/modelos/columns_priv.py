
from sqlalchemy import Integer, String, BigInteger, SmallInteger, Float, Numeric, Text
from sqlalchemy import Time, DateTime, Boolean, LargeBinary, Enum, JSON, Text, Date
from sqlalchemy import Column, ForeingKey
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import Mapped
from sqlalchemy.orm import mapped_column


class Columns_priv(Base):
    __tablename__ = 'columns_priv'

    Host = Column(String, primary_key=True, nullable=False)

    Db = Column(String, primary_key=True, nullable=False)

    User = Column(String, primary_key=True, nullable=False)

    Table_name = Column(String, primary_key=True, nullable=False)

    Column_name = Column(String, primary_key=True, nullable=False)

    Timestamp = Column(DateTime, nullable=False)

    Column_priv = Column(String, nullable=False)

