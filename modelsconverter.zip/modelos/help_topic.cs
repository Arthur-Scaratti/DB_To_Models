
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class Help_topic
    {

        [Required]
        [Key]
        public int Help_topic_id { get; set; }
        /// help_topic_id
        [Required]
        public string? Name { get; set; }
        /// name
        [Required]
        public short Help_category_id { get; set; }
        /// help_category_id
        [Required]
        public string? Description { get; set; }
        /// description
        [Required]
        public string? Example { get; set; }
        /// example
        [Required]
        public string? Url { get; set; }
        /// url
    }
}
