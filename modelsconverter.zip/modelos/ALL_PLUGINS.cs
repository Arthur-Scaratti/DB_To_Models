
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Models
{
    public class ALL_PLUGINS
    {

        [Required]
        [StringLength(64)]
        public string? PLUGIN_NAME { get; set; }
        /// PLUGIN_NAME
        [Required]
        [StringLength(20)]
        public string? PLUGIN_VERSION { get; set; }
        /// PLUGIN_VERSION
        [Required]
        [StringLength(16)]
        public string? PLUGIN_STATUS { get; set; }
        /// PLUGIN_STATUS
        [Required]
        [StringLength(80)]
        public string? PLUGIN_TYPE { get; set; }
        /// PLUGIN_TYPE
        [Required]
        [StringLength(20)]
        public string? PLUGIN_TYPE_VERSION { get; set; }
        /// PLUGIN_TYPE_VERSION
        [StringLength(64)]
        public string? PLUGIN_LIBRARY { get; set; }
        /// PLUGIN_LIBRARY
        [StringLength(20)]
        public string? PLUGIN_LIBRARY_VERSION { get; set; }
        /// PLUGIN_LIBRARY_VERSION
        [StringLength(64)]
        public string? PLUGIN_AUTHOR { get; set; }
        /// PLUGIN_AUTHOR
    
        public string? PLUGIN_DESCRIPTION { get; set; }
        /// PLUGIN_DESCRIPTION
        [Required]
        [StringLength(80)]
        public string? PLUGIN_LICENSE { get; set; }
        /// PLUGIN_LICENSE
        [Required]
        [StringLength(64)]
        public string? LOAD_OPTION { get; set; }
        /// LOAD_OPTION
        [Required]
        [StringLength(12)]
        public string? PLUGIN_MATURITY { get; set; }
        /// PLUGIN_MATURITY
        [StringLength(80)]
        public string? PLUGIN_AUTH_VERSION { get; set; }
        /// PLUGIN_AUTH_VERSION
    }
}
