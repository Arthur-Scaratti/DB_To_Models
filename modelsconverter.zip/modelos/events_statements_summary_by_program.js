
const Sequelize = require('sequelize');
const DataTypes = Sequelize.DataTypes;

const Events_statements_summary_by_program = Sequelize.define('events_statements_summary_by_program', {

    OBJECT_TYPE: {
        type: DataTypes.ENUM,
        allowNull: true,
        
    },

    OBJECT_SCHEMA: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    OBJECT_NAME: {
        type: DataTypes.STRING,
        allowNull: false,
        
    },

    COUNT_STAR: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_TIMER_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    COUNT_STATEMENTS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_STATEMENTS_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MIN_STATEMENTS_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    AVG_STATEMENTS_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    MAX_STATEMENTS_WAIT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_LOCK_TIME: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_ERRORS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_WARNINGS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_ROWS_AFFECTED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_ROWS_SENT: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_ROWS_EXAMINED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_CREATED_TMP_DISK_TABLES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_CREATED_TMP_TABLES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SELECT_FULL_JOIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SELECT_FULL_RANGE_JOIN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SELECT_RANGE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SELECT_RANGE_CHECK: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SELECT_SCAN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SORT_MERGE_PASSES: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SORT_RANGE: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SORT_ROWS: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_SORT_SCAN: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_NO_INDEX_USED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

    SUM_NO_GOOD_INDEX_USED: {
        type: DataTypes.BIGINT,
        allowNull: false,
        
    },

}, {
    timestamps: false,

});

module.exports = Events_statements_summary_by_program;