export interface APPLICABLE_ROLES {
    GRANTEE: string;

    ROLE_NAME: string;

    IS_GRANTABLE: string;

    IS_DEFAULT: string;

}