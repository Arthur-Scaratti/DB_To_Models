export interface Help_relation {
    Help_topic_id: number;

    Help_keyword_id: number;

}