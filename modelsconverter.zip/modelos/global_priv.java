import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class global_priv {
    @Id
    private String Host;

     @Id
    private String User;

     private String Priv;

 }