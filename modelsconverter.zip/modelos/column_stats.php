
<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Column_stats extends Model
{
    protected $table = 'column_stats';
   
    protected $primaryKey = ['Db_name', 'Table_name', 'Column_name'];

    public $timestamps = false;

    protected $fillable = [
        'Db_name',
        'Table_name',
        'Column_name',
        'Min_value',
        'Max_value',
        'Nulls_ratio',
        'Avg_length',
        'Avg_frequency',
        'Hist_size',
        'Hist_type',
        'Histogram',

    ];
}
