import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class file_instances {
    private String FILE_NAME;

     private String EVENT_NAME;

     private int OPEN_COUNT;

 }