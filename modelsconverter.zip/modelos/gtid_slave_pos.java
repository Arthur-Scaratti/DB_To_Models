import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Column;

@Entity
public class gtid_slave_pos {
    @Id
    private int Domain_id;

     @Id
    private long Sub_id;

     private int Server_id;

     private long Seq_no;

 }